#!/usr/bin/env python3
"""ShopFlow BA project documentation and synthetic datasets."""
import csv
import random
from datetime import datetime, timedelta
from pathlib import Path

from fpdf import FPDF

ROOT = Path("/workspace/artifacts/shopflow")
DATA = ROOT / "datasets"
SQL = ROOT / "sql"
random.seed(42)

CATEGORIES = [
    ("Fashion", ["Tops", "Bottoms", "Outerwear", "Footwear"]),
    ("Electronics", ["Audio", "Accessories", "Smart Home", "Computing"]),
    ("Home", ["Bedding", "Kitchen", "Decor", "Lighting"]),
    ("Beauty", ["Skincare", "Haircare", "Fragrance"]),
]
REGIONS = ["Northeast", "Midwest", "South", "West"]
STATES = {
    "Northeast": ["NY", "MA", "NJ", "PA"],
    "Midwest": ["IL", "OH", "MI", "MN"],
    "South": ["TX", "FL", "GA", "NC"],
    "West": ["CA", "WA", "CO", "AZ"],
}
CHANNELS = ["Organic Search", "Paid Search", "Email", "Social", "Direct", "Affiliate"]
PAYMENTS = ["Visa", "Mastercard", "Amex", "PayPal", "Shop Pay", "Apple Pay"]
STATUSES = ["delivered", "delivered", "delivered", "shipped", "processing", "cancelled"]
RETURN_REASONS = [
    "Size too small", "Size too large", "Not as described", "Changed mind",
    "Damaged in transit", "Wrong item", "Quality issue", "Late delivery",
]
FIRST = ["Ava", "Noah", "Mia", "Liam", "Sophia", "Ethan", "Olivia", "Mason", "Isla", "Lucas",
         "Amelia", "James", "Harper", "Benjamin", "Evelyn", "Henry", "Charlotte", "Owen", "Grace", "Jack"]
LAST = ["Chen", "Patel", "Garcia", "Nguyen", "Brooks", "Singh", "Kim", "Murphy", "Reed", "Shah",
        "Lopez", "Walker", "Adams", "Turner", "Bennett", "Foster", "Hughes", "Powell", "Coleman", "Russell"]


def money(n):
    return round(n, 2)


def build_data():
    products = []
    pid = 1000
    brands = {
        "Fashion": ["Northline", "Harbor & Co", "Fieldnote"],
        "Electronics": ["Auralis", "Nimbus", "Volt & Co"],
        "Home": ["Lumen House", "Oak & Linen", "Kettle"],
        "Beauty": ["Solace", "Marrow", "Atelier No."],
    }
    names = {
        "Tops": ["Merino Crew", "Oxford Shirt", "Rib Tank"],
        "Bottoms": ["Tailored Trouser", "Denim Straight", "Pleated Skirt"],
        "Outerwear": ["Wool Coat", "Rain Shell", "Quilted Jacket"],
        "Footwear": ["Leather Sneaker", "Chelsea Boot", "Canvas Loafer"],
        "Audio": ["Wireless Earbuds", "Over-Ear Headphones", "Portable Speaker"],
        "Accessories": ["USB-C Hub", "MagSafe Stand", "Travel Adapter"],
        "Smart Home": ["Smart Bulb 4-Pack", "Door Sensor", "Thermostat Mini"],
        "Computing": ["Mechanical Keyboard", "27-inch Monitor", "Laptop Sleeve"],
        "Bedding": ["Percale Sheet Set", "Down Alternative Duvet", "Linen Pillowcase Pair"],
        "Kitchen": ["Cast Iron Skillet", "Ceramic Pour-Over", "Glass Storage Set"],
        "Decor": ["Stoneware Vase", "Wool Throw", "Framed Print"],
        "Lighting": ["Brass Table Lamp", "Pendant Shade", "LED Floor Lamp"],
        "Skincare": ["Daily Moisturizer", "Vitamin C Serum", "Gentle Cleanser"],
        "Haircare": ["Repair Shampoo", "Leave-In Conditioner", "Scalp Oil"],
        "Fragrance": ["Citrus Eau", "Wood & Smoke", "Travel Atomizer"],
    }
    for cat, subs in CATEGORIES:
        for sub in subs:
            for nm in names[sub]:
                pid += 1
                cost = random.uniform(8, 180)
                price = money(cost * random.uniform(1.8, 3.4))
                products.append({
                    "product_id": f"P{pid}",
                    "product_name": nm,
                    "brand": random.choice(brands[cat]),
                    "category": cat,
                    "subcategory": sub,
                    "unit_cost": money(cost),
                    "list_price": price,
                    "active_flag": "Y" if random.random() > 0.05 else "N",
                })

    customers = []
    start = datetime(2024, 1, 1)
    for i in range(1, 801):
        region = random.choice(REGIONS)
        acquired = start + timedelta(days=random.randint(0, 640))
        customers.append({
            "customer_id": f"C{i:05d}",
            "first_name": random.choice(FIRST),
            "last_name": random.choice(LAST),
            "email": f"customer{i:05d}@example-mail.test",
            "region": region,
            "state": random.choice(STATES[region]),
            "acquisition_channel": random.choice(CHANNELS),
            "signup_date": acquired.strftime("%Y-%m-%d"),
            "loyalty_tier": random.choices(["None", "Silver", "Gold", "Platinum"], weights=[62, 22, 12, 4])[0],
            "marketing_opt_in": random.choice(["Y", "Y", "N"]),
        })

    orders, items, payments, returns, reviews, sessions = [], [], [], [], [], []
    oid = 50000
    rid = 1
    sid = 1
    day0 = datetime(2024, 6, 1)
    for _ in range(2400):
        oid += 1
        cust = random.choice(customers)
        order_dt = day0 + timedelta(days=random.randint(0, 480), hours=random.randint(8, 22), minutes=random.randint(0, 59))
        status = random.choice(STATUSES)
        channel = random.choice(CHANNELS)
        n_lines = random.choices([1, 2, 3, 4], weights=[55, 28, 12, 5])[0]
        chosen = random.sample(products, n_lines)
        subtotal = 0
        for line_no, p in enumerate(chosen, 1):
            qty = random.choices([1, 2, 3], weights=[78, 17, 5])[0]
            discount = random.choice([0, 0, 0, 0.1, 0.15, 0.2])
            unit = money(p["list_price"] * (1 - discount))
            line_total = money(unit * qty)
            subtotal += line_total
            items.append({
                "order_id": f"O{oid}",
                "line_no": line_no,
                "product_id": p["product_id"],
                "quantity": qty,
                "unit_price": unit,
                "discount_rate": discount,
                "line_revenue": line_total,
                "line_cost": money(p["unit_cost"] * qty),
            })
            if status == "delivered" and random.random() < 0.11:
                req = order_dt + timedelta(days=random.randint(2, 21))
                refunded = req + timedelta(days=random.randint(4, 16))
                returns.append({
                    "return_id": f"R{rid:05d}",
                    "order_id": f"O{oid}",
                    "product_id": p["product_id"],
                    "customer_id": cust["customer_id"],
                    "return_reason": random.choice(RETURN_REASONS),
                    "quantity": 1 if qty == 1 else random.randint(1, qty),
                    "requested_date": req.strftime("%Y-%m-%d"),
                    "refunded_date": refunded.strftime("%Y-%m-%d") if random.random() > 0.08 else "",
                    "refund_amount": money(unit * (1 if qty == 1 else 1)),
                    "status": "refunded" if random.random() > 0.08 else "pending_inspection",
                })
                rid += 1
        ship = money(0 if subtotal > 75 else 6.95)
        tax = money(subtotal * 0.07)
        total = money(subtotal + ship + tax)
        orders.append({
            "order_id": f"O{oid}",
            "customer_id": cust["customer_id"],
            "order_datetime": order_dt.strftime("%Y-%m-%d %H:%M:%S"),
            "order_status": status,
            "channel": channel,
            "region": cust["region"],
            "subtotal": money(subtotal),
            "shipping_amount": ship,
            "tax_amount": tax,
            "order_total": total,
            "promo_code": random.choice(["", "", "", "WELCOME10", "FALL15", "FREESHIP"]),
        })
        if status != "cancelled":
            payments.append({
                "payment_id": f"PAY{oid}",
                "order_id": f"O{oid}",
                "payment_method": random.choice(PAYMENTS),
                "payment_status": "captured" if status != "processing" else random.choice(["authorized", "captured"]),
                "amount": total,
                "paid_at": order_dt.strftime("%Y-%m-%d %H:%M:%S"),
            })
        if status == "delivered" and random.random() < 0.45:
            reviews.append({
                "review_id": f"RV{oid}",
                "order_id": f"O{oid}",
                "customer_id": cust["customer_id"],
                "product_id": chosen[0]["product_id"],
                "rating": random.choices([1, 2, 3, 4, 5], weights=[3, 5, 12, 35, 45])[0],
                "review_date": (order_dt + timedelta(days=random.randint(3, 20))).strftime("%Y-%m-%d"),
            })

    # Sessions / cart funnel sample — 5,000 sessions
    for i in range(1, 5001):
        cust_id = random.choice(customers)["customer_id"] if random.random() > 0.35 else ""
        session_dt = day0 + timedelta(days=random.randint(0, 480), hours=random.randint(0, 23))
        viewed = random.randint(1, 12)
        added = 0 if random.random() < 0.68 else random.randint(1, min(4, viewed))
        checkout = 1 if added and random.random() > 0.42 else 0
        purchased = 1 if checkout and random.random() > 0.28 else 0
        sessions.append({
            "session_id": f"S{i:06d}",
            "session_date": session_dt.strftime("%Y-%m-%d"),
            "customer_id": cust_id,
            "device": random.choices(["mobile", "desktop", "tablet"], weights=[58, 36, 6])[0],
            "channel": random.choice(CHANNELS),
            "pages_viewed": viewed,
            "added_to_cart": added,
            "reached_checkout": checkout,
            "purchased": purchased,
            "session_revenue": money(random.uniform(28, 240)) if purchased else 0,
        })

    tables = {
        "customers.csv": customers,
        "products.csv": products,
        "orders.csv": orders,
        "order_items.csv": items,
        "payments.csv": payments,
        "returns.csv": returns,
        "reviews.csv": reviews,
        "sessions.csv": sessions,
    }
    for name, rows in tables.items():
        with (DATA / name).open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    return tables


class Doc(FPDF):
    def __init__(self):
        super().__init__(format="A4")
        self.set_auto_page_break(auto=True, margin=18)
        self.add_font("DejaVu", "", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
        self.add_font("DejaVu", "B", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
        self.add_font("Serif", "", "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf")
        self.add_font("Serif", "B", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf")
        self.add_font("Mono", "", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf")

    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("DejaVu", "", 8)
        self.set_text_color(90, 90, 90)
        self.cell(0, 6, "ShopFlow Commerce  |  Business Analysis Project Dossier  |  CONFIDENTIAL — Portfolio Use", align="L")
        self.ln(2)
        self.set_draw_color(20, 40, 70)
        self.set_line_width(0.4)
        self.line(12, 14, 198, 14)
        self.ln(6)

    def footer(self):
        if self.page_no() == 1:
            return
        self.set_y(-14)
        self.set_font("DejaVu", "", 8)
        self.set_text_color(90, 90, 90)
        self.cell(0, 8, f"Document SF-BA-2026-001  ·  Version 1.0  ·  Page {self.page_no()}", align="C")

    def h1(self, text):
        self.ln(2)
        self.set_font("Serif", "B", 16)
        self.set_text_color(16, 32, 58)
        self.multi_cell(0, 8, text)
        self.set_draw_color(180, 140, 60)
        self.set_line_width(0.6)
        self.line(12, self.get_y() + 1, 70, self.get_y() + 1)
        self.ln(5)

    def h2(self, text):
        self.ln(1)
        self.set_font("DejaVu", "B", 12)
        self.set_text_color(24, 48, 82)
        self.multi_cell(0, 7, text)
        self.ln(1)

    def h3(self, text):
        self.set_font("DejaVu", "B", 11)
        self.set_text_color(40, 40, 40)
        self.multi_cell(0, 6, text)
        self.ln(1)

    def body(self, text):
        self.set_font("DejaVu", "", 10)
        self.set_text_color(30, 30, 30)
        self.multi_cell(0, 5.2, text)
        self.ln(2)

    def bullet(self, text):
        self.set_font("DejaVu", "", 10)
        self.set_text_color(30, 30, 30)
        self.multi_cell(0, 5.2, "•  " + text)
        self.ln(0.6)

    def table(self, headers, rows, col_w):
        self.set_font("DejaVu", "B", 8)
        self.set_fill_color(16, 32, 58)
        self.set_text_color(255, 255, 255)
        for i, h in enumerate(headers):
            self.cell(col_w[i], 7, h, border=0, fill=True)
        self.ln()
        self.set_font("DejaVu", "", 7.5)
        self.set_text_color(25, 25, 25)
        fill = False
        for r in rows:
            if self.get_y() > 265:
                self.add_page()
                self.set_font("DejaVu", "B", 8)
                self.set_fill_color(16, 32, 58)
                self.set_text_color(255, 255, 255)
                for i, h in enumerate(headers):
                    self.cell(col_w[i], 7, h, border=0, fill=True)
                self.ln()
                self.set_font("DejaVu", "", 7.5)
                self.set_text_color(25, 25, 25)
            if fill:
                self.set_fill_color(240, 243, 247)
            else:
                self.set_fill_color(255, 255, 255)
            # compute height
            heights = []
            for i, cell in enumerate(r):
                # rough
                lines = self.multi_cell(col_w[i], 4.4, str(cell), dry_run=True, output="LINES")
                heights.append(max(1, len(lines)) * 4.4)
            h = max(heights)
            x0, y0 = self.get_x(), self.get_y()
            if y0 + h > 275:
                self.add_page()
                y0 = self.get_y()
                x0 = self.get_x()
            for i, cell in enumerate(r):
                x = self.get_x()
                y = self.get_y()
                self.rect(x, y, col_w[i], h, style="F")
                self.multi_cell(col_w[i], 4.4, str(cell))
                self.set_xy(x + col_w[i], y)
            self.set_xy(x0, y0 + h)
            fill = not fill
        self.ln(3)


def main():
    tables = build_data()
    orders = tables["orders.csv"]
    items = tables["order_items.csv"]
    returns = tables["returns.csv"]
    sessions = tables["sessions.csv"]
    customers = tables["customers.csv"]
    products = tables["products.csv"]
    reviews = tables["reviews.csv"]
    gmv = sum(float(o["order_total"]) for o in orders if o["order_status"] != "cancelled")
    n_orders = sum(1 for o in orders if o["order_status"] != "cancelled")
    aov = gmv / n_orders
    sess_n = len(sessions)
    cart_rate = sum(1 for s in sessions if int(s["added_to_cart"]) > 0) / sess_n
    purch_rate = sum(1 for s in sessions if int(s["purchased"]) == 1) / sess_n
    ret_amt = sum(float(r["refund_amount"]) for r in returns)
    avg_rating = sum(int(r["rating"]) for r in reviews) / len(reviews)

    pdf = Doc()
    # COVER
    pdf.add_page()
    pdf.set_fill_color(16, 32, 58)
    pdf.rect(0, 0, 210, 297, "F")
    pdf.set_fill_color(180, 140, 60)
    pdf.rect(0, 0, 8, 297, "F")
    pdf.set_xy(22, 48)
    pdf.set_text_color(180, 140, 60)
    pdf.set_font("DejaVu", "", 11)
    pdf.cell(0, 8, "BUSINESS ANALYSIS  ·  PORTFOLIO CASE  ·  DOCUMENT SF-BA-2026-001")
    pdf.set_xy(22, 68)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Serif", "B", 28)
    pdf.multi_cell(165, 13, "ShopFlow Commerce\nExperience & Analytics\nTransformation")
    pdf.set_xy(22, 130)
    pdf.set_font("DejaVu", "", 12)
    pdf.set_text_color(220, 220, 220)
    pdf.multi_cell(160, 7,
        "A professional business-analysis dossier covering requirements,\n"
        "operating processes, data architecture, synthetic transactional\n"
        "datasets, acceptance criteria, and executive reporting design\n"
        "for a multi-category direct-to-consumer retailer.")
    pdf.set_xy(22, 190)
    pdf.set_font("DejaVu", "", 10)
    pdf.set_text_color(180, 140, 60)
    meta = [
        "Classification     Portfolio / educational use — synthetic data only",
        "Engagement type    Discovery, requirements, and analytics enablement",
        "Domain             Multi-category e-commerce (B2C)",
        "Version            1.0  —  Baseline for stakeholder review",
        "Prepared           27 October 2026",
        "Tools in scope     GitHub, Jira, wireframes, PostgreSQL, Power BI",
        "Currency           United States dollars (USD)",
    ]
    for line in meta:
        pdf.cell(0, 6.5, line)
        pdf.ln(6.5)
    pdf.set_xy(22, 260)
    pdf.set_text_color(180, 180, 180)
    pdf.set_font("DejaVu", "", 8)
    pdf.multi_cell(160, 4.5,
        "This dossier is a realistic simulation of delivery artefacts a Business Analyst would produce\n"
        "on a commerce transformation. All customer records, orders, and financial figures are synthetic.\n"
        "No live personal data is included. Email domains are non-routable.")

    # 1
    pdf.add_page()
    pdf.h1("1. Document control")
    pdf.body(
        "This document is the controlling baseline for the ShopFlow Commerce portfolio engagement. "
        "It defines why the work exists, what is in and out of scope, the requirements the solution must satisfy, "
        "the data the organisation will trust, and the acceptance evidence required before a release is considered complete. "
        "It is written for an executive sponsor, a product owner, engineering leads, finance, customer operations, and a reviewing hiring manager."
    )
    pdf.h2("1.1 Revision history")
    pdf.table(
        ["Version", "Date", "Author role", "Description"],
        [
            ["0.1", "06 Oct 2026", "Business Analyst", "Discovery notes and problem framing"],
            ["0.4", "14 Oct 2026", "Business Analyst", "AS-IS process, stakeholder map, draft BRD"],
            ["0.8", "21 Oct 2026", "Business Analyst", "Stories, data model, KPI catalogue"],
            ["1.0", "27 Oct 2026", "Business Analyst", "Baseline issued for review with datasets"],
        ],
        [28, 32, 45, 81],
    )
    pdf.h2("1.2 Distribution")
    pdf.table(
        ["Role", "Interest", "RACI on this baseline"],
        [
            ["Chief Commercial Officer", "Revenue, conversion, margin", "Accountable"],
            ["Head of Customer Operations", "Returns cycle time, CSAT", "Consulted"],
            ["Head of Finance", "Refund liability, revenue recognition", "Consulted"],
            ["Product Owner, Commerce", "Backlog priority and scope", "Responsible"],
            ["Analytics Lead", "Mart design and dashboard trust", "Responsible"],
            ["Engineering Lead", "Feasibility, NFRs, integrations", "Consulted"],
            ["Business Analyst", "Artefact quality and traceability", "Responsible"],
        ],
        [58, 72, 56],
    )
    pdf.h2("1.3 How to read this dossier")
    pdf.body(
        "Sections 2 to 6 establish commercial context and scope. Sections 7 to 11 are the requirements baseline: "
        "business rules, functional requirements, non-functional requirements, and agile stories with testable acceptance criteria. "
        "Sections 12 to 16 define the information architecture — logical model, physical datasets supplied with this pack, "
        "metric definitions, and the analytical questions leadership expects to answer. Sections 17 to 21 cover experience design, "
        "the Power BI information design, delivery governance in Jira and GitHub, verification, and risk. "
        "The appendices reproduce representative extracts of every dataset so a reviewer can inspect the evidence without opening the companion files."
    )
    pdf.body(
        "Companion files, issued with this PDF, are eight comma-separated datasets and a PostgreSQL script that creates the schema and the core analytical views. "
        "Figures quoted in the narrative were computed from those files at the time of issue and will reconcile if the scripts are re-run without alteration."
    )

    pdf.h1("2. Executive summary")
    pdf.body(
        "ShopFlow Commerce is a direct-to-consumer retailer selling fashion, electronics, home, and beauty through a single digital storefront. "
        "Annualised gross merchandise value on the observation window is consistent with a mid-market operator: the synthetic book contains "
        f"{n_orders:,} non-cancelled orders and approximately ${gmv:,.0f} in order value, at an average order value of ${aov:,.2f}. "
        "The commercial problem is not demand generation in isolation. It is leakage after intent, opacity after purchase, and an analytics estate that cannot explain either."
    )
    pdf.body(
        f"Session evidence shows that only {cart_rate:.1%} of sessions add an item to the basket, and {purch_rate:.1%} of sessions complete a purchase. "
        "The dominant failure is therefore upstream of checkout: customers browse and leave. Among those who do buy, returns are material. "
        f"The extract records {len(returns):,} return lines and ${ret_amt:,.0f} of refund value. Refunds are slow and poorly visible to the customer, "
        "which drives avoidable contact into the service centre. Review quality is otherwise healthy, with a mean rating of {avg_rating:.2f} out of 5, "
        "indicating that product sentiment is not the primary constraint — process and merchandising clarity are."
    )
    pdf.body(
        "This engagement specifies a controlled response in three workstreams that a Business Analyst would normally hold together: "
        "(1) a self-service returns and refund-status experience, with an operating process that finance and the warehouse can actually run; "
        "(2) instrumented understanding of cart abandonment, and a short list of product changes justified by the funnel; and "
        "(3) a trusted analytical layer in PostgreSQL, consumed by Power BI, so that revenue, margin, cohort retention, delivery, and returns are managed from one set of definitions."
    )
    pdf.h2("2.1 Decision requested of the sponsor")
    pdf.bullet("Approve the baseline scope in Section 5 as the content of the first two programme increments.")
    pdf.bullet("Accept the KPI definitions in Section 14 as the single source of commercial truth for the dashboards.")
    pdf.bullet("Authorise use of the supplied logical model as the contract between analytics and engineering.")
    pdf.bullet("Confirm that loyalty-programme rebuild, native mobile applications, and international tax engines remain out of scope.")
    pdf.h2("2.2 Outcomes the business should be able to claim")
    pdf.table(
        ["Outcome", "Baseline (synthetic)", "Target after release", "Owner"],
        [
            ["Session-to-purchase rate", f"{purch_rate:.1%}", "+1.5 percentage points", "Product"],
            ["Median refund cycle (days)", "9 to 12 (AS-IS)", "5 calendar days", "Operations"],
            ["Share of refund status calls", "High, unmeasured", "-40% of related contacts", "CX"],
            ["KPI disputes in monthly review", "Recurring", "Zero definitional disputes", "Analytics"],
            ["Repeat purchase visibility", "None", "Monthly cohort retained", "CRM"],
        ],
        [48, 40, 52, 46],
    )
    pdf.body(
        "Targets are management hypotheses for a portfolio case, not audited forecasts. They are stated so that every requirement later in this document can be traced to a commercial reason for existing."
    )

    pdf.h1("3. Business context")
    pdf.h2("3.1 The enterprise")
    pdf.body(
        "ShopFlow Commerce operates one brand, four category families, and a United States shipping footprint divided into Northeast, Midwest, South, and West. "
        "Fulfilment is a mix of owned inventory and a small set of drop-ship partners, modelled in this case as a single order line cost rather than a multi-node warehouse system. "
        "The customer base on file is 800 accounts. Acquisition is spread across organic search, paid search, email, social, direct, and affiliate. "
        "Loyalty is shallow: most customers sit in tier None, with Silver, Gold, and Platinum as progressive minorities. That distribution is intentional — it reflects a retailer that has a programme on paper and limited evidence that the programme changes behaviour."
    )
    pdf.h2("3.2 Commercial model")
    pdf.bullet("Revenue is recognised on captured payment for non-cancelled orders. Tax is modelled at a flat illustrative 7 percent, not a jurisdiction engine.")
    pdf.bullet("Shipping is complimentary above an order subtotal of 75 dollars and otherwise 6.95 dollars.")
    pdf.bullet("Promotional codes in the extract are WELCOME10, FALL15, and FREESHIP. Discount is applied at line level before tax.")
    pdf.bullet("Contribution is list economics minus unit cost, before marketing spend. The dataset does not contain media cost, so return on ad spend is explicitly out of the metric catalogue.")
    pdf.bullet("A return creates a refund amount against the affected line. Pending inspection is a real status; not every request is money out the door on day one.")
    pdf.h2("3.3 Why this matters now")
    pdf.body(
        "Three pressures arrive together. First, paid acquisition is less forgiving of a weak on-site conversion rate: every session that views and leaves is media already spent. "
        "Second, the service organisation is absorbing status-chasing on refunds that a competent self-service surface would answer. "
        "Third, monthly trading meetings reopen the same arguments — which figure is revenue, whether cancelled orders are included, how a cohort month is defined — because no mart is designated as the source of truth. "
        "A Business Analyst's job in this situation is not to design the database for its own sake. It is to force a single definition of the business, express it as requirements someone can build, and prove it with data a sceptic can recompute."
    )
    pdf.h2("3.4 Observation window")
    pdf.body(
        "Orders, payments, reviews, returns, and sessions cover 1 June 2024 through mid-to-late 2025 in the generated book (480 days from the window start, plus signup history from 1 January 2024). "
        "All analysis in the dashboards should default to this window and allow the user to narrow it. Year-on-year comparisons are valid only where both periods exist inside the window; the specification does not invent a prior year."
    )

    pdf.h1("4. Problem statement")
    pdf.h2("4.1 Problem as experienced by the customer")
    pdf.body(
        "A customer who wants to send something back cannot see, in one place, whether the request was received, whether the warehouse accepted the goods, and when money will return to the original tender. "
        "They email, they call, and they leave a review that is about the process rather than the product. Customers who are still deciding whether to buy meet a different failure: they view several products, rarely commit an item to the basket, and receive no credible reason to return — no saved basket for guests, no clear delivery promise, no size guidance where fashion returns later prove the size was the issue."
    )
    pdf.h2("4.2 Problem as experienced by the operator")
    pdf.body(
        "Customer operations works from inboxes and a spreadsheet extract. Finance sees refunds when the payment provider settles them, not when the customer expects them. "
        "Merchandising can rank products by revenue but cannot reliably rank them by contribution after returns. Marketing can see last-click channel on the order but cannot see whether that channel produces customers who buy a second time. "
        "Each team exports something slightly different. None of those exports is versioned."
    )
    pdf.h2("4.3 Problem statement (controlled wording)")
    pdf.body(
        "ShopFlow cannot currently tell a customer where their refund is, cannot explain where purchase intent dies, and cannot agree a single figure for revenue, margin, repeat purchase, or refund cycle time. "
        "Until those three gaps are closed, commercial decisions will continue to be made on partial extracts and service cost will continue to absorb work the product should do."
    )
    pdf.h2("4.4 Opportunity")
    pdf.body(
        "The same event stream that reveals the failure can fund the fix. Session flags (view, add, checkout, purchase) are sufficient to locate the break in the funnel without a full clickstream rebuild. "
        "Order, line, payment, and return tables are sufficient to compute contribution after returns. Customer signup month plus order month is sufficient for a classical cohort. "
        "The organisation does not have a data shortage. It has a definition shortage and an experience gap. Both are Business Analyst problems before they are engineering problems."
    )

    pdf.h1("5. Objectives and scope")
    pdf.h2("5.1 Objectives")
    pdf.table(
        ["ID", "Objective", "Measure of done"],
        [
            ["O1", "Give customers a truthful refund status without contacting support.", "Status page matches warehouse and finance states in UAT."],
            ["O2", "Cut refund cycle time by making the process explicit and measurable.", "Median requested-to-refunded days visible and trending to 5."],
            ["O3", "Explain cart abandonment with a trusted funnel.", "Session mart reconciles to the session extract within 0 rows."],
            ["O4", "Publish one executive and three operational views in Power BI.", "Each visual traces to a named mart and a named DAX or SQL definition."],
            ["O5", "Run the work as a visible Agile increment.", "Jira epic, stories, and RTM IDs match this baseline."],
        ],
        [16, 88, 82],
    )
    pdf.h2("5.2 In scope")
    pdf.bullet("Returns initiation, reason capture, inspection state, refund confirmation, and customer-visible status.")
    pdf.bullet("Cart and checkout funnel measurement; requirements for guest-basket persistence and a delivery-promise module. Build of the storefront itself is specified, not coded, in this dossier.")
    pdf.bullet("Logical and physical data model for customers, products, orders, lines, payments, returns, reviews, and sessions.")
    pdf.bullet("PostgreSQL staging-to-mart pattern and the metric catalogue.")
    pdf.bullet("Power BI information design: pages, visuals, filters, and acceptance checks.")
    pdf.bullet("Wireframe specification for the customer returns journey and the operations refund queue.")
    pdf.bullet("Jira structure, definition of ready, definition of done, and a requirements traceability matrix.")
    pdf.bullet("User-acceptance scenarios and a RAID log.")
    pdf.h2("5.3 Out of scope")
    pdf.bullet("Native iOS or Android applications. Responsive web behaviour is specified; a separate app is not.")
    pdf.bullet("Replatforming the storefront, replacing the payment service provider, or building a tax engine.")
    pdf.bullet("Warehouse management, slotting, or carrier contracting. The dossier consumes a delivery and inspection status; it does not design the warehouse.")
    pdf.bullet("Loyalty tier redesign, points liability, and personalised recommendation models.")
    pdf.bullet("Paid-media cost ingestion and return on ad spend.")
    pdf.bullet("Personally identifiable production data. Only synthetic records ship with this pack.")
    pdf.bullet("International selling, multi-currency, and multi-language content.")
    pdf.h2("5.4 Assumptions")
    pdf.bullet("A payment service provider can accept a refund against the original tender and return a provider reference.")
    pdf.bullet("The warehouse can post three states: received, accepted, rejected. Rejected is rare and must not silently become refunded.")
    pdf.bullet("Session data can be aggregated daily. Raw click-level storage is not required for the decisions in this baseline.")
    pdf.bullet("Stakeholders will accept USD and a single tax rate as the analytical simplification for this case.")
    pdf.bullet("GitHub is the system of record for documents and SQL. Jira is the system of record for delivery status. They are linked by requirement ID, not by prose.")
    pdf.h2("5.5 Constraints")
    pdf.bullet("No requirement in this baseline may depend on a tool the stated stack does not include, other than a wireframing canvas (Figma or equivalent).")
    pdf.bullet("Dashboards must remain correct if a user filters to a single region, category, or month. Definitions that only work unfiltered are defects.")
    pdf.bullet("Customer email addresses in the dataset are synthetic and must not be used as real contact lists.")

    pdf.h1("6. Stakeholders and governance")
    pdf.h2("6.1 Stakeholder map")
    pdf.body(
        "Influence and interest are assessed so the analyst spends elicitation time where a wrong requirement is expensive. "
        "The commercial sponsor can stop the work and owns the outcome numbers. Finance can invalidate a revenue definition after the dashboard is built, which is the most expensive kind of defect. "
        "Customer operations lives inside the returns process every day and will reject a design that looks finished and cannot be staffed. "
        "Engineering will not accept ambiguous acceptance criteria. Marketing cares about channel and cohort but does not own refund policy."
    )
    pdf.table(
        ["Stakeholder", "Influence", "Interest", "Engagement stance"],
        [
            ["CCO (sponsor)", "High", "High", "Decide scope and targets"],
            ["Finance controller", "High", "High", "Approve revenue and refund rules"],
            ["Head of CX / Ops", "Medium", "High", "Co-design the TO-BE process"],
            ["Product owner", "High", "High", "Prioritise and accept stories"],
            ["Analytics lead", "Medium", "High", "Own marts and certification"],
            ["Engineering lead", "High", "Medium", "Challenge feasibility early"],
            ["Merchandising", "Low", "High", "Consume product and return views"],
            ["CRM / retention", "Low", "High", "Consume cohort and RFM"],
            ["Warehouse lead", "Medium", "Medium", "Confirm inspection states"],
            ["Customer (proxy)", "Low", "High", "Validate the status journey"],
        ],
        [42, 28, 28, 88],
    )
    pdf.h2("6.2 Decision rights")
    pdf.body(
        "Priority conflicts are resolved by the product owner within the approved scope, and by the sponsor when a change crosses the scope boundary in Section 5. "
        "A change to a KPI definition is not a cosmetic change. It requires finance and the analytics lead to co-sign, and it requires the RTM row to be re-issued. "
        "The analyst does not silently 'improve' a definition inside a visual."
    )
    pdf.h2("6.3 Cadence")
    pdf.bullet("Weekly 45-minute backlog refinement, product owner and analyst, engineering optional.")
    pdf.bullet("Fortnightly sprint review with sponsor on a single page: funnel, refund cycle, and any definition dispute.")
    pdf.bullet("Decision log entry within one business day of any scope or KPI change. The log lives in GitHub under docs/decisions.")

    pdf.h1("7. Current-state and future-state process")
    pdf.h2("7.1 AS-IS — returns and refunds")
    pdf.body(
        "The customer emails support or uses a generic contact form. An agent looks up the order in the commerce admin, decides whether the item is inside a 30-day window, and replies with instructions that vary by agent. "
        "The customer ships the goods with a label that is sometimes prepaid and sometimes not. The warehouse receives the parcel into an unscanned area. "
        "When someone inspects it, they email finance. Finance raises a refund in the payment console when they next process the queue, which is not daily during peak. "
        "The customer is not told that the inspection happened. They contact support again. Support cannot see the finance queue, so they promise a date they do not control."
    )
    pdf.h3("Failure modes observed in the AS-IS")
    pdf.bullet("No single return identifier shared by the customer, the warehouse, and finance.")
    pdf.bullet("Policy (30 days from delivery, item condition, exclusion of final sale) is applied inconsistently because it is not system-enforced.")
    pdf.bullet("Cycle time is not measured. Leadership quotes a range, which means nobody owns the metric.")
    pdf.bullet("Reason codes are free text, so merchandising cannot learn that size, not quality, drives fashion returns.")
    pdf.bullet("A cancelled order and a refunded delivered order are sometimes added together in homemade reports.")
    pdf.h2("7.2 TO-BE — returns and refunds")
    pdf.body(
        "The customer opens the order, selects eligible lines, chooses a reason from a controlled list, and receives a return identifier and a prepaid label when the policy allows it. "
        "The return moves through four customer-visible states: Requested, In transit, Inspecting, Refunded (or Declined, with a reason). "
        "Warehouse scans the identifier on receipt and posts Accepted or Rejected. Finance refunds only on Accepted, against the original tender, and the provider reference is written back to the return. "
        "The status page and the transactional email use the same state machine. Support sees the same state machine. There is nothing for an agent to interpret."
    )
    pdf.h2("7.3 Control points")
    pdf.table(
        ["Step", "Control", "System evidence"],
        [
            ["Eligibility", "Delivered, within 30 days, not final-sale", "Order status + delivery date + product flag"],
            ["Identity", "Return tied to order line and customer", "return_id, order_id, product_id"],
            ["Reason", "Controlled list, not free text only", "return_reason enumeration"],
            ["Receipt", "Scan required before inspection", "received timestamp"],
            ["Refund", "Only from Accepted; amount <= line net", "refund_amount, payment reference"],
            ["Customer truth", "One status API for page, email, agent", "status history"],
        ],
        [32, 78, 76],
    )
    pdf.h2("7.4 Cart journey — analytical AS-IS, product TO-BE")
    pdf.body(
        "Today the business can export orders. It cannot export a trustworthy view-to-cart-to-checkout-to-purchase funnel, so abandonment is a slogan. "
        "The TO-BE instrument is deliberately small: one session row with device, channel, pages viewed, items added, checkout reached, and purchased. "
        "Product changes justified by that instrument, and therefore in scope as requirements rather than as opinions, are: persistent baskets for recognised customers, a guest email capture that restores a basket, a delivery promise on the product page before add-to-cart, and size guidance on fashion items with a high size-related return rate. "
        "Recommendation carousels and a loyalty rebuild are explicitly not justified by the evidence in this pack and stay out of scope."
    )

    pdf.h1("8. Business requirements")
    pdf.body(
        "Business requirements describe outcomes and rules. They do not describe screens or tables. Each requirement has an identifier that appears again in the traceability matrix. "
        "Priority uses MoSCoW. Must items are required for the release to be accepted. Should items are expected in the same programme unless the sponsor trades them. Could items are sequenced behind."
    )
    brs = [
        ["BR-01", "Must", "A customer can determine the status of a refund without contacting support."],
        ["BR-02", "Must", "Refund cycle time is measurable from request to money movement, in calendar days."],
        ["BR-03", "Must", "Return reasons are classifiable, so merchandising can separate size, damage, and preference."],
        ["BR-04", "Must", "Revenue, orders, and average order value exclude cancelled orders and are defined once."],
        ["BR-05", "Must", "Contribution after returns is visible at category level, not only gross sales."],
        ["BR-06", "Must", "The business can see where sessions fail: view, basket, checkout, or purchase."],
        ["BR-07", "Must", "Repeat purchase is visible as a monthly acquisition cohort, not as a vague loyalty claim."],
        ["BR-08", "Should", "Channel of acquisition is comparable on first order and on 90-day repeat."],
        ["BR-09", "Should", "Region performance is comparable without redefining geography in each report."],
        ["BR-10", "Should", "Review score is reportable beside return rate so quality and fit are not confused."],
        ["BR-11", "Should", "Finance can isolate refunds still pending inspection from refunds already captured."],
        ["BR-12", "Could", "Loyalty tier is available as a slice, without a redesign of the programme."],
        ["BR-13", "Must", "Every published KPI names its grain, its filter behaviour, and its source mart."],
        ["BR-14", "Must", "A change to a KPI definition is versioned and approved, not edited inside a visual."],
        ["BR-15", "Should", "Support agents and customers see the same return state, with the same words."],
        ["BR-16", "Must", "A refund cannot exceed the net amount paid for the returned quantity."],
        ["BR-17", "Must", "Declined returns remain visible and are not counted as refunded cash."],
        ["BR-18", "Could", "Promo-code usage is reportable against order margin, for later commercial review."],
    ]
    pdf.table(["ID", "Priority", "Requirement"], [[a, b, c] for a, b, c in brs], [22, 22, 142])

    pdf.h2("8.1 Business rules")
    rules = [
        ["R1", "An order in status cancelled contributes nothing to revenue, orders, AOV, or margin."],
        ["R2", "Order total equals subtotal plus shipping plus tax. Subtotal is the sum of line revenue."],
        ["R3", "Shipping is 0 when subtotal is strictly greater than 75; otherwise 6.95, unless a FREESHIP code is present (then 0)."],
        ["R4", "Tax in this case is 7 percent of subtotal. It is not a real tax determination."],
        ["R5", "A line is return-eligible when the order is delivered and the request is within 30 days of delivery. The extract simplifies delivery as the order date plus fulfilment; the rule still stands for the product."],
        ["R6", "Refund amount for a line cannot exceed unit price times returned quantity."],
        ["R7", "Return status pending_inspection is not cash refunded. It is a liability, not a completed refund."],
        ["R8", "A session is a purchase only when purchased = 1. Reaching checkout is not a purchase."],
        ["R9", "Cohort month is the month of the customer's first non-cancelled order, not the signup month, unless a view explicitly says signup cohort."],
        ["R10", "Average order value is revenue divided by non-cancelled orders, never by sessions and never by lines."],
        ["R11", "Return rate by units is returned units divided by delivered units, not by orders."],
        ["R12", "Guest sessions have a null customer_id and must not be dropped from the funnel."],
        ["R13", "Ratings are integers from 1 to 5. A missing review is not a zero."],
        ["R14", "Region on the order is the customer's region at order time in this extract. It is not re-derived from state in the visual layer."],
    ]
    pdf.table(["Rule", "Statement"], rules, [18, 168])

    pdf.h1("9. Functional requirements")
    pdf.body(
        "Functional requirements state what the solution does. They are written so a tester can fail them. "
        "They cover three product surfaces: the customer returns experience, the operations console, and the analytical products (SQL marts and Power BI). "
        "Wireframes in Section 17 illustrate the first two; they do not replace these statements."
    )
    frs = [
        ["FR-01", "The customer can open an order and see which lines are eligible for return, with the reason for any ineligibility."],
        ["FR-02", "The customer can select a quantity not greater than the purchased quantity and a reason from the controlled list."],
        ["FR-03", "On submit, the system creates a return identifier and shows it immediately."],
        ["FR-04", "The system offers a prepaid label when the return is eligible and the reason is not 'changed mind' on items under 15 dollars. Otherwise it explains why a label is not offered."],
        ["FR-05", "The status page shows Requested, In transit, Inspecting, Refunded, or Declined, and the timestamp of the latest transition."],
        ["FR-06", "A transactional message is sent on each transition, using the same labels as the status page."],
        ["FR-07", "An agent can search by order identifier, customer email, or return identifier and sees the same status."],
        ["FR-08", "The warehouse user can post Received, then Accepted or Rejected, and must enter a note on Rejected."],
        ["FR-09", "Finance can release a refund only from Accepted. The amount defaults to the eligible net and can be reduced, never increased."],
        ["FR-10", "The payment reference is stored on the return when the provider accepts the refund."],
        ["FR-11", "The session mart exposes, by day, device, and channel: sessions, sessions with an add, sessions reaching checkout, purchases, and purchase revenue."],
        ["FR-12", "The revenue mart exposes, by day, region, and category: orders, units, revenue, cost, refund amount, and contribution after refunds."],
        ["FR-13", "The customer mart exposes RFM scores on a defined snapshot date, with the scoring method documented beside the view."],
        ["FR-14", "The cohort mart exposes customers acquired in month M and the share ordering again in month M+k for k = 0 to 6 where data exists."],
        ["FR-15", "Power BI pages specified in Section 18 exist, each visual bound to a mart, each page filterable by date."],
        ["FR-16", "A user applying a region filter sees every visual on the page respect it, including rates, not only absolute sums."],
        ["FR-17", "Cancelled orders never appear in revenue visuals. They may appear in a separate cancellation count."],
        ["FR-18", "The product catalogue can be filtered to active items. Inactive items remain in history and are not deleted."],
        ["FR-19", "Exports from Power BI, if enabled, carry the metric definition name and the refresh timestamp."],
        ["FR-20", "GitHub contains the SQL that builds every mart the dashboard uses. A mart without SQL in the repository is not accepted."],
    ]
    pdf.table(["ID", "Statement"], frs, [20, 166])

    pdf.h1("10. Non-functional requirements")
    pdf.table(
        ["ID", "Category", "Requirement"],
        [
            ["NFR-01", "Trust", "Mart row counts reconcile to the certified extract before a dashboard is marked refreshed."],
            ["NFR-02", "Trust", "A failed refresh does not display yesterday's numbers under today's timestamp."],
            ["NFR-03", "Performance", "Status page returns the current state in under two seconds at the 95th percentile on the reference profile."],
            ["NFR-04", "Performance", "Executive page in Power BI interacts (filter change) in under three seconds on the certified model."],
            ["NFR-05", "Security", "Agents see customer data only inside the operations role. The public status page requires order id plus email or a signed link."],
            ["NFR-06", "Security", "Synthetic portfolio data contains no real personal data and uses a non-routable email domain."],
            ["NFR-07", "Audit", "Status transitions are append-only. A state is not overwritten without history."],
            ["NFR-08", "Audit", "KPI definition changes are committed in Git with a decision-log reference."],
            ["NFR-09", "Availability", "Status lookup is available during checkout peak; it does not depend on the warehouse UI being open."],
            ["NFR-10", "Privacy", "Dashboards used in a portfolio or wide distribution show aggregates. Row-level customer names are confined to the operations role."],
            ["NFR-11", "Usability", "Status labels are plain language. Internal codes do not appear on the customer page."],
            ["NFR-12", "Usability", "The primary action on each wireframed screen is visually singular. Secondary actions do not compete with it."],
            ["NFR-13", "Maintainability", "SQL views are layered raw, staging, mart. Dashboards do not contain business rules that contradict the mart."],
            ["NFR-14", "Accessibility", "Status is not conveyed by colour alone. Text labels accompany every state."],
            ["NFR-15", "Portability", "The SQL is valid PostgreSQL 15 or later and does not depend on a proprietary warehouse dialect."],
        ],
        [22, 32, 132],
    )

    pdf.h1("11. Epics, user stories, and acceptance criteria")
    pdf.body(
        "Stories follow the INVEST properties: independent enough to sequence, negotiable on implementation, valuable to a named role, estimable by engineering, small enough for a sprint, and testable by the acceptance criteria below. "
        "Criteria use Given / When / Then so they can be pasted into Jira without rewriting. Story points are deliberately omitted; a portfolio case that invents velocity is less credible than one that shows sliceable work."
    )
    pdf.h2("11.1 Epic E1 — Customer refund truth")
    pdf.body("Business outcome: a customer can see where a refund is, and operations can move the return without email. Traces to BR-01, BR-02, BR-03, BR-15, BR-16, BR-17.")
    stories = [
        ("US-01", "As a customer, I want to start a return from my delivered order, so that I do not have to explain the order to an agent.",
         "Given a delivered order inside 30 days and a line that is not final-sale, when I choose a quantity within the purchased quantity and a reason, then I receive a return identifier and the state is Requested."),
        ("US-02", "As a customer, I want ineligible lines explained, so that I do not submit a return the policy will refuse.",
         "Given a line outside the window or marked final-sale, when I open the order, then the line cannot be selected and the page states the specific reason."),
        ("US-03", "As a customer, I want the status of my return in the same words the email uses, so that I can trust what I am told.",
         "Given a return that moves from Requested to Inspecting, when I open the status page and when I read the email, then both say Inspecting and show the same timestamp."),
        ("US-04", "As a warehouse associate, I want to scan a return identifier, so that receipt is recorded against the right order line.",
         "Given a return in Requested or In transit, when I post Received, then the timestamp is stored and the customer state becomes Inspecting only after inspection starts, not on mere receipt."),
        ("US-05", "As a finance analyst, I want to refund only accepted goods, and never more than was paid, so that we do not create a loss by keystroke.",
         "Given a return in Accepted, when I confirm the refund, then the amount cannot exceed unit price times quantity, the provider reference is stored, and the state becomes Refunded."),
        ("US-06", "As a finance analyst, I want declined returns excluded from refunded cash, so that liability is not overstated.",
         "Given a Rejected inspection, when the mart refreshes, then refunded cash excludes it and pending liability excludes it, and a declined count includes it."),
        ("US-07", "As a support agent, I want to find a return by email, order, or return id, so that I stop asking the customer to repeat themselves.",
         "Given any one of those keys, when I search, then I see the current state, the history, and the reason, and I cannot edit the history."),
    ]
    for sid, story, ac in stories:
        pdf.h3(sid)
        pdf.body(story)
        pdf.body("Acceptance: " + ac)

    pdf.h2("11.2 Epic E2 — Funnel clarity and the two product fixes")
    pdf.body("Business outcome: the business can point to the step that leaks, and two product changes exist because the data requires them. Traces to BR-06 and the TO-BE in Section 7.4.")
    stories2 = [
        ("US-08", "As a product manager, I want a daily funnel by device and channel, so that I stop debating where abandonment happens.",
         "Given the session extract, when the mart is built, then sessions, add-to-cart sessions, checkout sessions, and purchases equal the extract for every day."),
        ("US-09", "As a returning customer, I want my basket kept, so that a closed browser is not a lost purchase.",
         "Given I am signed in and I add an item, when I return within 14 days on any device, then the item is still in the basket at the same quantity unless stock has gone."),
        ("US-10", "As a guest, I want to save my basket with an email, so that I can finish the purchase without creating a full account first.",
         "Given a guest basket with at least one item, when I submit an email, then I can restore that basket from the link, and the session is still counted as a guest until an account exists."),
        ("US-11", "As a shopper, I want a delivery promise before I add to cart, so that I am not surprised by timing at checkout.",
         "Given a shippable product and a destination region, when I view the product, then I see a delivery window or an explicit statement that the window is unavailable."),
        ("US-12", "As a merchandiser, I want size-related return rate beside the fashion product, so that size guidance is added where it pays for itself.",
         "Given fashion products, when I open the product performance page, then I see units, revenue, and the share of returns whose reason is size."),
    ]
    for sid, story, ac in stories2:
        pdf.h3(sid)
        pdf.body(story)
        pdf.body("Acceptance: " + ac)

    pdf.h2("11.3 Epic E3 — One commercial truth")
    pdf.body("Business outcome: monthly trading uses one set of numbers. Traces to BR-04, BR-05, BR-07, BR-13, BR-14.")
    stories3 = [
        ("US-13", "As a commercial director, I want revenue, orders, and AOV on one page, so that I can see whether we grew.",
         "Given a date range, when I open the executive page, then revenue equals the sum of order totals for non-cancelled orders in that range, and AOV equals that revenue divided by those orders."),
        ("US-14", "As a merchandiser, I want contribution after refunds by category, so that I do not celebrate a category that comes back.",
         "Given the revenue mart, when I compare categories, then contribution equals line revenue minus line cost minus refund amount allocated to the category."),
        ("US-15", "As a CRM lead, I want a cohort heatmap, so that I can see whether recent customers come back.",
         "Given customers with a first non-cancelled order in month M, when I read column k, then the cell is the share of that cohort with a non-cancelled order in month M+k."),
        ("US-16", "As an analyst, I want RFM segments that I can explain, so that marketing does not treat the label as magic.",
         "Given a snapshot date, when scores are computed, then recency is days since last order, frequency is order count, monetary is revenue, and the quintile method is written in the view comment."),
        ("US-17", "As a reviewer of this programme, I want every visual traceable to SQL in GitHub, so that the dashboard cannot drift from the contract.",
         "Given a visual on any specified page, when I ask for its source, then the analyst can name the view and the file."),
    ]
    for sid, story, ac in stories3:
        pdf.h3(sid)
        pdf.body(story)
        pdf.body("Acceptance: " + ac)

    pdf.h2("11.4 Definition of ready and done")
    pdf.body(
        "A story is ready when it has a persona, a benefit, acceptance criteria, a trace to a business requirement, and no unresolved dependency that engineering has not seen. "
        "A story is done when acceptance criteria pass in the agreed environment, the RTM is updated, any SQL is merged, and the analyst has checked that dashboard copy uses the approved metric name. "
        "Done does not mean the sponsor liked the chart colours."
    )

    pdf.h1("12. Logical data model")
    pdf.body(
        "The model is a constellation of conformed dimensions around order and session facts. It is intentionally boring. "
        "Boring models survive contact with finance. The grain of each fact is stated because most commercial arguments are grain arguments in disguise."
    )
    pdf.h2("12.1 Entities and grain")
    pdf.table(
        ["Entity", "Grain", "Role"],
        [
            ["customer", "One row per customer account", "Dimension"],
            ["product", "One row per sellable SKU", "Dimension"],
            ["order", "One row per customer order", "Fact header"],
            ["order_item", "One row per order line", "Fact"],
            ["payment", "One row per payment attempt captured or authorised", "Fact"],
            ["return", "One row per returned product request on a line", "Fact"],
            ["review", "One row per review of a product on an order", "Fact"],
            ["session", "One row per site session", "Fact"],
        ],
        [32, 90, 64],
    )
    pdf.h2("12.2 Relationships")
    pdf.bullet("A customer places zero or many orders. An order belongs to exactly one customer.")
    pdf.bullet("An order has one or many lines. A line references exactly one product.")
    pdf.bullet("An order has zero or one payment in this extract (cancelled orders may have none).")
    pdf.bullet("A line may have zero or many return requests. The extract usually has at most one.")
    pdf.bullet("A review references one order, one customer, and one product.")
    pdf.bullet("A session may have a null customer (guest). It does not reference an order identifier; purchase is a flag plus session revenue, which will not equal order revenue and must never be added to it.")
    pdf.h2("12.3 Conformed attributes")
    pdf.body(
        "Region, state, and acquisition channel live on the customer. Region is copied onto the order so that a later address change does not rewrite history. "
        "Category and subcategory live on the product and are reached from the line by product_id. "
        "Channel on the order is the converting session's channel and may differ from acquisition channel. Reports must say which one they mean. The executive page uses order channel. The cohort commentary may use acquisition channel. They are not interchangeable, and the labelling says so."
    )
    pdf.h2("12.4 Layering")
    pdf.body(
        "raw holds the files as loaded, with no business rules. staging casts types, rejects orphan lines, and standardises empty strings to null. "
        "mart holds the objects Power BI is allowed to touch: fact_orders_enriched, fact_funnel_daily, fact_cohort_retention, fact_customer_rfm, and dim tables. "
        "A visual that computes contribution with its own DAX expression of cost and refunds, ignoring the mart, is a defect even if the number happens to match today."
    )
    pdf.h2("12.5 Keys and data quality expectations")
    pdf.bullet("Primary keys: customer_id, product_id, order_id, (order_id, line_no), payment_id, return_id, review_id, session_id.")
    pdf.bullet("Every order_item.order_id exists in orders. Every order_item.product_id exists in products. Every order.customer_id exists in customers.")
    pdf.bullet("Refund amount is non-negative. Quantity is a positive integer. Rating is between 1 and 5.")
    pdf.bullet("order_status is one of processing, shipped, delivered, cancelled.")
    pdf.bullet("Session purchased is 0 or 1, and purchased cannot be 1 when reached_checkout is 0. The generator honours this; the staging layer should still enforce it.")

    pdf.h1("13. Dataset catalogue")
    pdf.body(
        "Eight files accompany this document. They are synthetic, generated with a fixed random seed so the pack is reproducible, and sized to be serious enough to dashboard without being theatrical. "
        "Email addresses use the reserved-style domain example-mail.test and must not be mailed. Names are combinations from short lists, not real customers."
    )
    pdf.table(
        ["File", "Rows (this issue)", "Grain"],
        [
            ["customers.csv", f"{len(customers):,}", "Customer account"],
            ["products.csv", f"{len(products):,}", "SKU"],
            ["orders.csv", f"{len(orders):,}", "Order"],
            ["order_items.csv", f"{len(items):,}", "Order line"],
            ["payments.csv", f"{len(tables['payments.csv']):,}", "Payment"],
            ["returns.csv", f"{len(returns):,}", "Return request"],
            ["reviews.csv", f"{len(reviews):,}", "Review"],
            ["sessions.csv", f"{len(sessions):,}", "Web session"],
        ],
        [48, 50, 88],
    )
    pdf.h2("13.1 customers.csv")
    pdf.table(
        ["Column", "Type", "Definition"],
        [
            ["customer_id", "text", "Surrogate business key, C plus five digits."],
            ["first_name", "text", "Synthetic given name."],
            ["last_name", "text", "Synthetic family name."],
            ["email", "text", "Synthetic, non-routable."],
            ["region", "text", "Northeast, Midwest, South, or West."],
            ["state", "text", "US state abbreviation inside the region."],
            ["acquisition_channel", "text", "Channel that created the account."],
            ["signup_date", "date", "Account creation date. Not the cohort month."],
            ["loyalty_tier", "text", "None, Silver, Gold, Platinum."],
            ["marketing_opt_in", "text", "Y or N. Not evidence of consent in a legal sense."],
        ],
        [42, 22, 122],
    )
    pdf.h2("13.2 products.csv")
    pdf.table(
        ["Column", "Type", "Definition"],
        [
            ["product_id", "text", "Business key, P plus digits."],
            ["product_name", "text", "Customer-facing name."],
            ["brand", "text", "House brand within the category."],
            ["category", "text", "Fashion, Electronics, Home, Beauty."],
            ["subcategory", "text", "Merchandising family inside the category."],
            ["unit_cost", "numeric", "Fully loaded unit cost used for contribution. Not a supplier invoice."],
            ["list_price", "numeric", "Price before line discount."],
            ["active_flag", "text", "Y if currently sold. History is retained either way."],
        ],
        [36, 24, 126],
    )
    pdf.h2("13.3 orders.csv")
    pdf.table(
        ["Column", "Type", "Definition"],
        [
            ["order_id", "text", "Business key."],
            ["customer_id", "text", "Ordering customer."],
            ["order_datetime", "timestamp", "When the order was placed."],
            ["order_status", "text", "processing, shipped, delivered, cancelled."],
            ["channel", "text", "Converting channel. Not acquisition channel."],
            ["region", "text", "Region copied at order time."],
            ["subtotal", "numeric", "Sum of line revenue."],
            ["shipping_amount", "numeric", "Charged shipping."],
            ["tax_amount", "numeric", "Illustrative tax."],
            ["order_total", "numeric", "Subtotal + shipping + tax."],
            ["promo_code", "text", "Blank or a known code."],
        ],
        [40, 28, 118],
    )
    pdf.h2("13.4 order_items.csv")
    pdf.table(
        ["Column", "Type", "Definition"],
        [
            ["order_id", "text", "Parent order."],
            ["line_no", "integer", "Line number within the order, starting at 1."],
            ["product_id", "text", "SKU sold."],
            ["quantity", "integer", "Units sold."],
            ["unit_price", "numeric", "Price after discount, before tax."],
            ["discount_rate", "numeric", "Fraction off list, e.g. 0.10."],
            ["line_revenue", "numeric", "unit_price times quantity."],
            ["line_cost", "numeric", "unit_cost times quantity."],
        ],
        [36, 24, 126],
    )
    pdf.h2("13.5 payments.csv, returns.csv, reviews.csv, sessions.csv")
    pdf.table(
        ["Column", "Definition"],
        [
            ["payment_id / order_id", "One payment row for non-cancelled orders."],
            ["payment_method", "Visa, Mastercard, Amex, PayPal, Shop Pay, Apple Pay."],
            ["payment_status", "authorized or captured."],
            ["amount / paid_at", "Amount should equal order_total when captured."],
            ["return_id", "Identifier the customer and warehouse share."],
            ["return_reason", "Controlled list: size, description, mind-change, damage, wrong item, quality, lateness."],
            ["requested_date / refunded_date", "Refunded date blank when not yet refunded."],
            ["refund_amount / status", "status is refunded or pending_inspection."],
            ["review rating / review_date", "1–5. Absence of a row means no review, not a bad review."],
            ["session_id / session_date", "One row per session."],
            ["device", "mobile, desktop, or tablet."],
            ["pages_viewed", "Count of product or content views in the session."],
            ["added_to_cart", "Count of add events. Zero means the session never committed an item."],
            ["reached_checkout / purchased", "Flags. Purchased implies checkout."],
            ["session_revenue", "Illustrative revenue on purchasing sessions. Do not add to order revenue."],
        ],
        [55, 131],
    )
    pdf.h2("13.6 Known limitations of the extract (state them before someone else does)")
    pdf.bullet("Delivery timestamp is not a separate column. Cycle-time measurement in production must use actual delivery and refund timestamps; the extract supports requested-to-refunded only.")
    pdf.bullet("There is no inventory position, so stock-out cannot be proven as a cause of abandonment.")
    pdf.bullet("Session revenue is not allocated to orders. Funnel value and ledger revenue are different questions.")
    pdf.bullet("Tax is flat. Do not brief this number as a tax liability.")
    pdf.bullet("Cost is a modelled unit cost, suitable for contribution ranking, not for a statutory gross-margin filing.")
    pdf.bullet("No fraud labels, no chargebacks, no partial shipments.")

    pdf.h1("14. Metric catalogue")
    pdf.body(
        "If a number is not in this catalogue, it is not an official ShopFlow number. Proposed additions go through the decision log. "
        "Each metric states grain, formula, and the principal wrong interpretation the analyst should pre-empt."
    )
    metrics = [
        ["Revenue", "Order, filtered", "Sum of order_total where status is not cancelled.", "Do not use subtotal if the conversation is about what the customer paid."],
        ["Orders", "Order", "Count of orders where status is not cancelled.", "Do not count lines."],
        ["AOV", "As filtered", "Revenue / Orders.", "Not revenue per customer."],
        ["Units", "Line", "Sum of quantity on non-cancelled orders.", "Cancelled lines are excluded via the order."],
        ["Product sales", "Line", "Sum of line_revenue on non-cancelled orders.", "Excludes shipping and tax. Say so on the visual."],
        ["Cost", "Line", "Sum of line_cost on those lines.", "Modelled cost, see limitations."],
        ["Refunded cash", "Return", "Sum of refund_amount where status is refunded.", "Pending inspection is not cash."],
        ["Pending refund liability", "Return", "Sum of refund_amount where status is pending_inspection.", "A stock, not a flow, unless dated carefully."],
        ["Contribution after refunds", "Category or total", "Product sales minus cost minus refunded cash.", "Does not deduct media."],
        ["Refund cycle days", "Return", "refunded_date minus requested_date, where refunded.", "Median, not mean, is the management number. Mean is distorted by tails."],
        ["Unit return rate", "Product", "Returned units / delivered units.", "Not return orders over all orders."],
        ["Sessions", "Session", "Count of session rows.", "Includes guests."],
        ["Add rate", "Session", "Sessions with added_to_cart > 0 / sessions.", "This is the primary leak in the current book."],
        ["Checkout rate", "Session", "Sessions with reached_checkout = 1 / sessions.", "Conditional checkout-of-adds is a second view, labelled as such."],
        ["Purchase rate", "Session", "Sessions with purchased = 1 / sessions.", "Not equal to orders divided by sessions if a session could hold multiple orders; here it cannot."],
        ["Repeat rate (cohort)", "Cohort cell", "Customers in cohort M with an order in M+k / customers in cohort M.", "k = 0 is 100 percent by construction if the cohort is order-based. Do not celebrate it."],
        ["Average rating", "Review", "Mean of rating. Unreviewed orders are excluded.", "Do not impute a score."],
        ["Cancellation rate", "Order", "Cancelled orders / all orders.", "Shown apart from revenue."],
    ]
    pdf.table(["Metric", "Grain", "Formula and the mistake to avoid"], [[a, b, c + " " + d] for a, b, c, d in metrics], [38, 28, 120])

    pdf.h2("14.1 RFM method (snapshot)")
    pdf.body(
        "On a chosen snapshot date, consider customers with at least one non-cancelled order on or before that date. "
        "Recency is the number of days between the snapshot and the latest such order; lower is better; score 5 is the best quintile. "
        "Frequency is the count of such orders; higher is better. Monetary is the sum of order_total; higher is better. "
        "Quintiles are computed within the snapshot population. A customer in the top quintile of all three is labelled Champion. "
        "Top monetary and weak recency is labelled At risk. Everyone else keeps a readable compound label (for example High value / recent) rather than a code. "
        "The method is documented in the SQL comment because a segment name without a method is a slogan."
    )

    pdf.h1("15. Analytical questions the pack is built to answer")
    pdf.body("These are the questions the sponsor is entitled to ask in a review. If the dashboard cannot answer one of them, the dashboard is incomplete, not the question.")
    questions = [
        "Did revenue, orders, and AOV rise or fall, and was the movement volume or basket size?",
        "Which categories produce contribution after refunds, not merely sales?",
        "Which regions contribute, and is the mix different from the customer-count mix?",
        "What share of revenue sits in the top products, and is that concentration increasing?",
        "How long do refunds take, and which reasons dominate?",
        "Are size reasons concentrated in particular fashion subcategories?",
        "Where does the session funnel break, and does mobile break in the same place as desktop?",
        "Which acquisition channels produce customers who order again within 90 days?",
        "What does retention look like by first-order month for the next six months?",
        "Do higher review scores coexist with higher return rates on any category, suggesting fit rather than defects?",
        "How much refund value is still pending inspection versus already paid out?",
        "What happens to the narrative if cancelled orders are wrongly included? The analyst should be able to show the distortion.",
    ]
    for i, q in enumerate(questions, 1):
        pdf.bullet(f"Q{i}. {q}")
    pdf.ln(2)
    pdf.h2("15.1 Illustrative reading of this issue (not a forecast)")
    pdf.body(
        f"On the issued extract, non-cancelled order value is ${gmv:,.0f} across {n_orders:,} orders, AOV ${aov:,.2f}. "
        f"Session add rate is {cart_rate:.1%} and session purchase rate is {purch_rate:.1%}, so the management conversation starts at the product view, not at the payment button. "
        f"Refund value recorded is ${ret_amt:,.0f} across {len(returns):,} return lines. Mean review score is {avg_rating:.2f}. "
        "These figures will move if the generator seed or volumes change. The definitions will not. A reviewer who recomputes revenue from orders.csv by excluding cancelled status should match the executive visual. That reconciliation is the acceptance test for trust, and it matters more than the aesthetic of the chart."
    )
    pdf.h2("15.2 What a good monthly narrative sounds like")
    pdf.body(
        "A competent commentary is four sentences. What happened to revenue and whether it was orders or AOV. Where contribution diverged from sales because of returns. Where the funnel broke, by device. What action is proposed, tied to a story already in the backlog, not to a new idea invented in the meeting. "
        "Anything longer is an appendix. The Business Analyst's discipline is to keep the meeting on the catalogue."
    )

    pdf.h1("16. PostgreSQL implementation notes")
    pdf.body(
        "The companion script schema.sql creates the eight tables and a small set of views. It is written for PostgreSQL. "
        "Loading is a COPY or \\copy from the CSV files, with headers. The script does not attempt to be an orchestration framework. "
        "Airflow, dbt, and a warehouse can come later; they are not required to prove the definitions. Pretending otherwise is a common portfolio inflation."
    )
    pdf.h2("16.1 Load order")
    pdf.bullet("customers, products, then orders, then order_items, payments, returns, reviews, sessions.")
    pdf.bullet("Foreign keys are declared so an orphan line fails the load rather than failing the board meeting.")
    pdf.bullet("After load, run the reconciliation queries included at the foot of the script: order totals versus lines, payment amounts versus orders, funnel sums versus the file.")
    pdf.h2("16.2 View responsibilities")
    pdf.table(
        ["View", "Responsibility"],
        [
            ["stg_orders", "Casts, nulls blank promos, flags is_cancelled."],
            ["mart_order_line", "Line grain with category, region, and order status attached."],
            ["mart_revenue_daily", "Day, region, category: revenue components and refunds."],
            ["mart_funnel_daily", "Day, device, channel: the four funnel counts."],
            ["mart_refund_cycle", "One row per refunded return with cycle days and reason."],
            ["mart_cohort", "Cohort month by age month, customers and repeat customers."],
        ],
        [42, 144],
    )
    pdf.h2("16.3 Worked reconciliation (the analyst runs these before demoing)")
    pdf.body(
        "Revenue check: sum of order_total where order_status is distinct from cancelled. "
        "Line check: for every order, sum of line_revenue equals subtotal, within one cent. "
        "Funnel check: count of sessions equals count of session_id; sum of purchased equals the purchase-rate numerator. "
        "Refund check: no refund_amount exceeds the parent line's line_revenue. "
        "If any check fails, the dashboard is not shown. Showing it anyway trains the sponsor to distrust the next true number."
    )
    pdf.h2("16.4 Indexing for the case, not for a platform fantasy")
    pdf.body(
        "Index foreign keys used in joins (customer_id, product_id, order_id) and the order timestamp. "
        "That is sufficient at this volume. Do not add a dozen speculative indexes to look thorough."
    )

    pdf.h1("17. Experience specification and wireframes")
    pdf.body(
        "Wireframes for this engagement are low-to-mid fidelity. They fix structure, priority, and state, not brand expression. "
        "A visual design that changes a label, hides ineligibility, or adds a second primary button has not implemented the requirement, however polished it looks. "
        "The canvases are expected in Figma (or an equivalent) and exported to the GitHub folder /wireframes, one frame per state listed here."
    )
    pdf.h2("17.1 Customer — order detail with return entry")
    pdf.bullet("Header: order identifier, date, status, total paid.")
    pdf.bullet("Lines: image placeholder, name, variant if any, quantity, line paid, eligibility.")
    pdf.bullet("Eligible line: quantity stepper bounded by purchased quantity, reason dropdown, checkbox.")
    pdf.bullet("Ineligible line: checkbox absent, reason in text (for example, outside the 30-day window).")
    pdf.bullet("Primary button: Continue, enabled only when at least one eligible line is selected.")
    pdf.bullet("Secondary text link: Return policy, opening the rules, not a new journey that loses the selection.")
    pdf.h2("17.2 Customer — confirm and label")
    pdf.bullet("Summary of selected lines, reasons, and estimated refund (merchandise only; tax treatment stated in one sentence).")
    pdf.bullet("Explicit statement when a prepaid label is or is not included, with the rule from FR-04 in customer language.")
    pdf.bullet("Primary button: Submit return. After success, the identifier is the dominant element on the page, selectable to copy.")
    pdf.h2("17.3 Customer — status")
    pdf.bullet("Five possible labels, exactly: Requested, In transit, Inspecting, Refunded, Declined.")
    pdf.bullet("A simple stepper shows which have occurred. Future steps are visible but not coloured as complete.")
    pdf.bullet("Declined shows the warehouse note translated into a customer-safe sentence, not the raw internal comment if it contains operational jargon.")
    pdf.bullet("Refunded shows amount and the last four characters of the provider reference, not the full token.")
    pdf.bullet("No marketing module on this page. The customer came for money, not a recommendation.")
    pdf.h2("17.4 Operations — refund queue")
    pdf.bullet("Default filter: Accepted and not yet refunded. Other states available, not default.")
    pdf.bullet("Columns: return id, age in days, customer region, amount, reason, order id.")
    pdf.bullet("Row opens a drawer with history. The refund action sits in the drawer, not as a careless icon on the row.")
    pdf.bullet("Amount field is pre-filled and rejects a value above the eligible net.")
    pdf.h2("17.5 Empty, error, and loading states (required frames, not optional polish)")
    pdf.bullet("No orders: explain that returns apply to delivered orders and offer a link to order history, which may itself be empty.")
    pdf.bullet("Search miss in the agent console: state that nothing matched, do not show another customer's data as a suggestion.")
    pdf.bullet("Provider failure on refund: state remains Accepted, error is visible to finance, customer state does not say Refunded.")
    pdf.bullet("Loading: the primary button does not double-submit. A second click is ignored while the first is in flight.")
    pdf.h2("17.6 Content principles")
    pdf.body(
        "Use the words in the state machine and nowhere a synonym. Do not say 'processed' if the state is Refunded. Do not say 'we're sorry you didn't love it' on a damage return. "
        "The tone is calm and specific. Specificity is the courtesy: identifier, amount, date, and what happens next."
    )

    pdf.h1("18. Power BI information design")
    pdf.body(
        "Four pages. No more, until these four are trusted. A twelve-page portfolio dashboard that cannot reconcile is worse than a short one that can. "
        "The model is Import from the marts, not DirectQuery, at this volume. A scheduled refresh timestamp is visible on every page footer."
    )
    pdf.h2("18.1 Page A — Executive")
    pdf.bullet("Cards: Revenue, Orders, AOV, Refunded cash, Purchase rate. Each card has a comparison versus the prior period of equal length.")
    pdf.bullet("Column and line: revenue by month, orders as the line, so volume and value can diverge visibly.")
    pdf.bullet("Bar: contribution after refunds by category.")
    pdf.bullet("Small table: top five products by product sales, with unit return rate beside them.")
    pdf.bullet("Slicers: date, region. Category is a cross-filter from the bar, not a second competing slicer row.")
    pdf.h2("18.2 Page B — Merchandising")
    pdf.bullet("Matrix: category, subcategory, product sales, cost, refunded cash, contribution, units, unit return rate.")
    pdf.bullet("Stacked bar of return reasons for the selected subcategory.")
    pdf.bullet("Scatter of average rating against unit return rate, one mark per subcategory, so fit problems separate from poor reviews.")
    pdf.bullet("Slicers: date, category, active flag.")
    pdf.h2("18.3 Page C — Customer quality")
    pdf.bullet("Cohort matrix, rows as first-order month, columns as months since, values as repeat rate. k = 0 visually de-emphasised because it is tautological.")
    pdf.bullet("Bar of customers by RFM label on the selected snapshot.")
    pdf.bullet("Table: acquisition channel, customers, revenue of first order, share with a second order inside 90 days.")
    pdf.bullet("Text box on the page stating the RFM method in two lines, not a tooltip nobody opens.")
    pdf.h2("18.4 Page D — Funnel and refunds operations")
    pdf.bullet("Funnel or waterfall: sessions, added, reached checkout, purchased, by the selected device.")
    pdf.bullet("Lines: add rate by week, split by mobile and desktop.")
    pdf.bullet("Card: median refund cycle days. Distribution histogram of cycle days.")
    pdf.bullet("Table: pending inspection amount by age bucket (0–3, 4–7, 8–14, 15+). This is the operational queue, not a vanity metric.")
    pdf.h2("18.5 Visual rules")
    pdf.bullet("Currency is formatted with a thousands separator and no false precision beyond cents on cards; charts may round to whole dollars if labelled.")
    pdf.bullet("Rates are percentages with one decimal.")
    pdf.bullet("Colour encodes one thing. Do not also encode category in the same hue scale used for 'bad cycle time'.")
    pdf.bullet("Titles are claims or names, not 'Chart 3'. Example: 'Contribution after refunds, by category'.")
    pdf.bullet("A footnote on pages A and D states that cancelled orders are excluded from revenue and included only in cancellation rate, which lives on page A as a quiet secondary figure.")
    pdf.h2("18.6 Acceptance of a page")
    pdf.body(
        "A page is accepted when: every visual maps to a catalogue metric; the date slicer changes every visual; a region slicer changes rates as well as sums; "
        "the reconciliation queries match the cards for an unfiltered full window; and a colleague who did not build it can explain AOV without opening the model. "
        "Aesthetic review is allowed only after that list is true."
    )

    pdf.h1("19. Delivery system: Jira and GitHub")
    pdf.h2("19.1 Repository")
    pdf.body(
        "Repository name: shopflow-commerce-ba. Default branch is main, protected. The analyst may not force-push. "
        "Folders: /docs (this dossier's markdown twin and the decision log), /wireframes (exports), /sql (schema and marts), /data (the eight CSVs or a pointer if size requires Git LFS), /powerbi (the pbix and a measures note). "
        "The README states how to load PostgreSQL, how to reconcile, and which Jira epics map to which folders. A repository that is only a dashboard file is not this project."
    )
    pdf.h2("19.2 Branching and review")
    pdf.bullet("SQL changes on a branch, reviewed by the analytics lead, merged only with the reconciliation queries green.")
    pdf.bullet("Requirement text changes update the RTM in the same commit as the story text.")
    pdf.bullet("Binary wireframe exports are committed when a story reaches ready, not at the end.")
    pdf.h2("19.3 Jira project")
    pdf.body(
        "Project key SF. Issue types used: Epic, Story, Task, Bug, Decision. Sub-tasks are allowed for engineering; the analyst's acceptance lives on the story, not buried in a sub-task. "
        "Epics: SF Epic E1 Customer refund truth, E2 Funnel clarity, E3 One commercial truth. "
        "Each story's summary starts with its US identifier. Labels: br-id, and one of experience, data, reporting. "
        "The board is a simple Scrum board. Columns: Ready, In progress, In review, Done. Backlog holds items not yet ready. "
        "A sprint is two weeks. The first sprint should contain US-13, US-08, and the schema load — trust before theatre — plus US-01 and US-03 if design capacity exists. Refunds without a definition of revenue is how programmes start sideways."
    )
    pdf.h2("19.4 Workflow rules")
    pdf.bullet("No story moves to Done without the acceptance criteria checked and the RTM row updated.")
    pdf.bullet("Bugs cite the FR or NFR they violate.")
    pdf.bullet("Scope additions are Decisions, not silent stories. A Decision links to the sponsor's answer.")
    pdf.h2("19.5 Traceability matrix")
    pdf.body("The matrix is the spine of the dossier. A requirement with no story will not be built. A story with no requirement should not have been written. A test with no story cannot be interpreted.")
    rtm = [
        ["BR-01", "FR-03, FR-05, FR-06", "US-01, US-03", "UAT-01, UAT-02"],
        ["BR-02", "FR-05", "US-03", "UAT-03"],
        ["BR-03", "FR-02", "US-01, US-12", "UAT-04"],
        ["BR-04", "FR-13, FR-17", "US-13", "UAT-10"],
        ["BR-05", "FR-12", "US-14", "UAT-11"],
        ["BR-06", "FR-11", "US-08", "UAT-12"],
        ["BR-07", "FR-14", "US-15", "UAT-13"],
        ["BR-13", "FR-15, FR-20", "US-17", "UAT-14"],
        ["BR-15", "FR-06, FR-07", "US-03, US-07", "UAT-02, UAT-05"],
        ["BR-16", "FR-09", "US-05", "UAT-06"],
        ["BR-17", "FR-09", "US-06", "UAT-07"],
        ["NFR-05", "FR-07", "US-07", "UAT-08"],
        ["NFR-13", "FR-20", "US-17", "UAT-14"],
    ]
    pdf.table(["Requirement", "Functions", "Stories", "Tests"], rtm, [28, 48, 48, 62])
    pdf.body("The remaining business requirements (BR-08 through BR-12, BR-14, BR-18) map to US-15, US-16, the decision log, and page-level acceptance in Section 18. They are not orphaned; they are slices of E3 rather than new epics.")

    pdf.h1("20. Verification and user acceptance")
    pdf.body(
        "Acceptance is evidence, not a meeting that felt positive. Each scenario below names the data condition, the action, and the expected observation. "
        "Scenarios are written so they can be executed against the synthetic data plus a thin prototype of the status rules. Where the prototype does not yet exist, the data scenarios (UAT-10 onward) are still executable today."
    )
    uats = [
        ["UAT-01", "Eligible return", "Delivered order, day 10, standard product.", "Submit quantity 1 and reason Size too small.", "Return id issued, state Requested, quantity cannot exceed purchased."],
        ["UAT-02", "Status parity", "Return moved to Inspecting.", "Open page and read email.", "Both show Inspecting and the same timestamp."],
        ["UAT-03", "Cycle metric", "A refunded return with known dates.", "Compute days in SQL and on page D.", "Median inputs match to the day."],
        ["UAT-04", "Reason class", "Fashion line returned for size.", "Open merchandising reason bar.", "Size reasons include that return; free text was not required."],
        ["UAT-05", "Agent search", "Known email.", "Search.", "Only that customer's returns. No neighbour suggestion."],
        ["UAT-06", "Refund cap", "Line revenue 40.", "Attempt refund 41.", "Rejected. 40 accepted. Provider reference stored."],
        ["UAT-07", "Declined", "Inspection rejected.", "Refresh mart.", "Not in refunded cash. Present in declined count."],
        ["UAT-08", "Access", "Public status URL without token or email check.", "Open.", "Does not reveal the return."],
        ["UAT-09", "Double submit", "Slow network.", "Click Submit twice.", "One return id."],
        ["UAT-10", "Revenue", "Full orders.csv.", "Sum non-cancelled order_total.", "Matches executive card unfiltered."],
        ["UAT-11", "Contribution", "One category.", "Sales minus cost minus refunded.", "Matches the category bar."],
        ["UAT-12", "Funnel", "sessions.csv.", "Count purchased = 1.", "Matches purchase-rate numerator."],
        ["UAT-13", "Cohort k=0", "Any cohort.", "Read first column.", "Equals 100 percent and is visually de-emphasised."],
        ["UAT-14", "Lineage", "Any card.", "Ask for the view.", "File in /sql named, and Git history shows it."],
        ["UAT-15", "Filter honesty", "Region = West.", "Read AOV.", "AOV recomputed on Western orders only, not a filtered sum over an unfiltered count."],
        ["UAT-16", "Guest sessions", "customer_id blank.", "Funnel totals.", "Guests included."],
        ["UAT-17", "Pending liability", "status pending_inspection.", "Page D buckets.", "Amount present in liability, absent from refunded cash."],
        ["UAT-18", "Cancellation distortion", "Include cancelled on purpose.", "Show both figures.", "The gap is explainable in one sentence."],
    ]
    pdf.table(["Test", "Focus", "Condition and expected result"], [[a, b, c + " Action: " + d + " Expect: " + e] for a, b, c, d, e in uats], [20, 32, 134])
    pdf.h2("20.1 Exit criteria for the case")
    pdf.bullet("UAT-10, UAT-12, UAT-15, and UAT-17 pass on the issued files. These do not require a storefront.")
    pdf.bullet("Wireframe frames listed in Section 17 exist for every state, including empty and error.")
    pdf.bullet("RTM has no Must requirement without a story and a test.")
    pdf.bullet("README lets a second person load the database and match revenue without asking the author.")

    pdf.h1("21. Risks, assumptions, issues, dependencies")
    pdf.table(
        ["ID", "Type", "Item", "Mitigation or owner"],
        [
            ["RK-01", "Risk", "Dashboard ships before reconciliation, sponsor loses trust.", "Exit criteria. Analyst blocks the demo."],
            ["RK-02", "Risk", "Session revenue is added to order revenue by a later author.", "Catalogue forbids it. Labels say so. Reviewer checks."],
            ["RK-03", "Risk", "Free-text reasons creep back in via an 'Other' box.", "Other must still map to a class, or it is out of policy."],
            ["RK-04", "Risk", "Refund initiated from the row icon, double paid.", "Action lives in the drawer. UAT-09 pattern applied."],
            ["RK-05", "Risk", "Scope expands into loyalty because the data has a tier column.", "Tier is a slice. Programme redesign is out of scope in writing."],
            ["AS-01", "Assumption", "Provider can refund original tender.", "Sponsor confirms before E1 build, not after."],
            ["AS-02", "Assumption", "Warehouse will scan identifiers.", "Ops owner. Without scans, status is fiction."],
            ["IS-01", "Issue", "No true delivery timestamp in the extract.", "Documented limitation. Do not pretend cycle time is delivery-based."],
            ["DP-01", "Dependency", "Payment reference write-back.", "Engineering. Customer state stays Accepted until it exists."],
            ["DP-02", "Dependency", "GitHub and Jira access for reviewers.", "Product owner, day one."],
        ],
        [18, 24, 78, 66],
    )
    pdf.h2("21.1 Ethical and presentational note")
    pdf.body(
        "This is a portfolio simulation. It is professional only if it is honest about that. The README and any interview narration should say the data are synthetic, the targets are hypotheses, and the reconciliation is the thing to be proud of. "
        "Inventing a claimed percentage-point lift as if it had been measured in production would turn a strong case into a weak one. The dossier therefore separates baseline observation from target."
    )

    pdf.h1("22. Roadmap")
    pdf.table(
        ["Increment", "Intent", "Evidence of exit"],
        [
            ["0. Foundations", "Repository, Jira, load, reconciliation, metric catalogue agreed.", "Second person reproduces revenue."],
            ["1. Truth", "Executive and funnel pages on marts. Stories US-08, US-13, US-17.", "UAT-10 to UAT-15 pass."],
            ["2. Refund visibility", "Wireframes approved, status rules, queue, cycle time on page D.", "UAT-01 to UAT-09 pass in prototype or build."],
            ["3. Customer quality", "Cohort, RFM, channel repeat. Merchandising matrix.", "UAT-11, UAT-13. Narrative dry-run with sponsor."],
            ["4. Product fixes", "Persistent basket, guest save, delivery promise specified into delivery.", "Stories US-09 to US-11 accepted against a build."],
        ],
        [32, 80, 74],
    )
    pdf.body(
        "Increment 4 is specified here so it is not forgotten, and sequenced last so the programme does not build basket persistence before it can measure whether anything changed. "
        "A Business Analyst who starts with the interface and hopes the numbers will follow has inverted the risk."
    )

    pdf.h1("23. Interview narrative")
    pdf.body(
        "When asked to walk through the work, the analyst should be able to do it in under six minutes without opening a tool, and then survive questions with the tool open. Suggested spine:"
    )
    pdf.bullet("The business leaked intent before checkout and could not see refunds. I wrote that as a problem statement with a number, not as a theme.")
    pdf.bullet("I separated what the business needs (refund truth, funnel, one definition of revenue) from what I refused to pretend to solve (loyalty redesign, tax, media ROI).")
    pdf.bullet("I turned rules into identifiers. Cancelled orders are out of revenue. Pending inspection is not cash. Guests stay in the funnel. k=0 on a cohort is not a success.")
    pdf.bullet("I published data a sceptic can recompute, SQL that states the rules once, and a dashboard that is not allowed to invent its own.")
    pdf.bullet("I would judge the work by reconciliation and by whether a support agent and a customer see the same word, not by the number of charts.")
    pdf.h2("23.1 Questions a strong interviewer will ask, and the position this dossier takes")
    pdf.bullet("Why is AOV not revenue per customer? Because the commercial lever this month is basket and order count; customer value belongs to the cohort page.")
    pdf.bullet("Why median cycle time? Because a single aged refund dominates the mean and would send the team chasing an outlier.")
    pdf.bullet("Why not a machine-learning recommender? Because the funnel says people are not adding to cart. A recommender does not fix a delivery promise or a size guide.")
    pdf.bullet("What would you cut if the sprint slips? The guest-basket story before the status parity story. Opacity of refunds is a trust defect; basket persistence is an optimisation.")
    pdf.bullet("How do you know the data is synthetic? Because this document says so, the domain is non-routable, and the generator seed is fixed.")

    pdf.h1("24. Glossary")
    glossary = [
        ["AOV", "Average order value. Revenue divided by non-cancelled orders."],
        ["Contribution", "Product sales minus modelled cost minus refunded cash. Not statutory margin."],
        ["Cohort", "Customers grouped by the month of their first non-cancelled order."],
        ["Grain", "What one row means. The source of most reporting arguments."],
        ["Mart", "A view or table certified for dashboard use. Business rules live here."],
        ["MoSCoW", "Must, Should, Could, Won't. Priority, not a sequence of build phases by itself."],
        ["RFM", "Recency, frequency, monetary value. A transparent segmentation, not a model score."],
        ["RTM", "Requirements traceability matrix. Links rules to stories to tests."],
        ["Session", "A visit. Not an order. May be guest."],
        ["TO-BE", "The operating process the requirements describe, as distinct from today's process."],
    ]
    pdf.table(["Term", "Meaning in this dossier"], glossary, [32, 154])

    pdf.h1("25. Appendix A — representative data extracts")
    pdf.body(
        "Extracts are the first rows of each issued file, not a curated highlight reel. They exist so a reviewer can see shape and quality. "
        "Full populations are in the companion CSV files. Do not compute official metrics from the extracts; they are samples of rows, not stratified samples."
    )

    def emit_extract(title, rows, cols, widths):
        pdf.h2(title)
        show = []
        for r in rows[:12]:
            show.append([str(r[c])[:28] for c in cols])
        pdf.table(cols, show, widths)

    emit_extract(
        "A.1 Customers (first 12)",
        customers,
        ["customer_id", "region", "state", "acquisition_channel", "signup_date", "loyalty_tier"],
        [24, 28, 16, 40, 28, 30],
    )
    emit_extract(
        "A.2 Products (first 12)",
        products,
        ["product_id", "product_name", "category", "subcategory", "unit_cost", "list_price"],
        [22, 42, 28, 32, 22, 22],
    )
    emit_extract(
        "A.3 Orders (first 12)",
        orders,
        ["order_id", "customer_id", "order_status", "channel", "region", "order_total"],
        [24, 28, 28, 36, 28, 24],
    )
    emit_extract(
        "A.4 Order lines (first 12)",
        items,
        ["order_id", "line_no", "product_id", "quantity", "unit_price", "line_revenue"],
        [28, 20, 28, 22, 28, 30],
    )
    emit_extract(
        "A.5 Payments (first 12)",
        tables["payments.csv"],
        ["payment_id", "order_id", "payment_method", "payment_status", "amount"],
        [32, 28, 40, 36, 30],
    )
    emit_extract(
        "A.6 Returns (first 12)",
        returns,
        ["return_id", "order_id", "return_reason", "requested_date", "status", "refund_amount"],
        [24, 24, 36, 30, 36, 28],
    )
    emit_extract(
        "A.7 Reviews (first 12)",
        reviews,
        ["review_id", "order_id", "product_id", "rating", "review_date"],
        [32, 28, 28, 22, 32],
    )
    emit_extract(
        "A.8 Sessions (first 12)",
        sessions,
        ["session_id", "device", "channel", "pages_viewed", "added_to_cart", "purchased"],
        [28, 24, 36, 28, 30, 24],
    )

    pdf.h1("26. Appendix B — category composition of the catalogue")
    from collections import Counter
    cat_counts = Counter(p["category"] for p in products)
    sub_counts = Counter((p["category"], p["subcategory"]) for p in products)
    pdf.table(
        ["Category", "SKUs"],
        [[k, str(v)] for k, v in sorted(cat_counts.items())],
        [60, 40],
    )
    pdf.table(
        ["Category", "Subcategory", "SKUs"],
        [[a, b, str(c)] for (a, b), c in sorted(sub_counts.items())],
        [40, 50, 30],
    )
    pdf.body(
        "Each subcategory is seeded with three named products so the merchandising matrix has a stable, human-readable grain. "
        "Prices are derived from a randomised cost and a margin multiple between 1.8 and 3.4. They are internally consistent and not scraped from a live retailer."
    )

    pdf.h1("27. Appendix C — SQL contract (abbreviated)")
    pdf.body("The full script is schema.sql beside this PDF. The following statements are the contract, abbreviated so the dossier stands alone if the script is separated.")
    sql_bits = [
        "Revenue: SELECT SUM(order_total) AS revenue, COUNT(*) AS orders FROM orders WHERE order_status <> 'cancelled';",
        "AOV: revenue / NULLIF(orders, 0) using the same filter. Never mix a filtered numerator with an unfiltered denominator.",
        "Line tie-out: SUM(line_revenue) GROUP BY order_id equals orders.subtotal.",
        "Funnel: COUNT(*) sessions, COUNT(*) FILTER (WHERE added_to_cart > 0), COUNT(*) FILTER (WHERE reached_checkout = 1), COUNT(*) FILTER (WHERE purchased = 1).",
        "Refunded cash: SUM(refund_amount) FROM returns WHERE status = 'refunded'.",
        "Cycle: PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY refunded_date - requested_date) WHERE status = 'refunded'.",
        "Cohort age 0 must equal the cohort size. If it does not, the first-order definition is wrong.",
        "Guests: sessions with customer_id IS NULL remain in every funnel aggregate.",
    ]
    for s in sql_bits:
        pdf.set_font("Mono", "", 8)
        pdf.set_text_color(20, 20, 20)
        pdf.multi_cell(0, 4.4, s)
        pdf.ln(1.5)
    pdf.set_font("DejaVu", "", 10)
    pdf.body(
        "Implementation detail may vary (filters in a WHERE clause versus a flag on the staging view). The numbers may not. "
        "If a more elegant query produces a different revenue figure, the elegant query is wrong."
    )

    pdf.h1("28. Appendix D — controlled vocabularies")
    pdf.h2("D.1 Order status")
    pdf.body("processing: paid or authorised, not yet handed to the carrier. shipped: handed over, not yet delivered. delivered: in the customer's possession; the return window starts. cancelled: no revenue, no refund path except an exceptional payment-void which is outside this baseline.")
    pdf.h2("D.2 Return status (customer language and internal mapping)")
    pdf.table(
        ["Customer label", "Internal condition"],
        [
            ["Requested", "Identifier created. Label may or may not be issued."],
            ["In transit", "Carrier scan received, warehouse has not."],
            ["Inspecting", "Warehouse received the goods. Decision not final."],
            ["Refunded", "Accepted and provider reference stored."],
            ["Declined", "Rejected at inspection. Cash not moved."],
        ],
        [40, 146],
    )
    pdf.h2("D.3 Return reasons")
    pdf.body(", ".join(RETURN_REASONS) + ".")
    pdf.body("Size too small and Size too large are kept apart because the merchandising response differs (guide versus fit model). Reporting may roll them up only in a view that is explicitly named size-related, never by overwriting the source.")
    pdf.h2("D.4 Channels and devices")
    pdf.body("Channels: " + ", ".join(CHANNELS) + ". Devices: mobile, desktop, tablet. A new channel is a decision, because it changes comparisons. It is not a free-text value an analyst types into a slicer.")

    pdf.h1("29. Appendix E — sample customer and agent dialogue (acceptance language)")
    pdf.body("These dialogues are acceptance aids. If the interface cannot support the conversation, the interface is early, not the customer unreasonable.")
    pdf.h3("E.1 Customer")
    pdf.body("Customer: I sent the coat back last week. Have you got it? Product: Return R-01422 is Inspecting. We received it on 18 October. If we accept it, the refund goes back to the card ending 4412. You do not need to call; this page and the email change together. Customer: What if you don't accept it? Product: The status will say Declined and will say why, in the same place.")
    pdf.h3("E.2 Agent")
    pdf.body("Agent searches the email, sees Inspecting, and does not offer a date the finance queue has not committed. If the customer asks for a date, the agent says the current state and the published target for the state (inspection within two business days of receipt), which is an operating policy, not a guess.")
    pdf.h3("E.3 Sponsor in the monthly review")
    pdf.body("Sponsor: Revenue is up but you look unhappy. Analyst: Orders are flat, AOV is up, and contribution in fashion is down because size returns rose. The action is US-12, size guidance on the two subcategories driving the reason code, not a new promotion. Sponsor: Why not a discount? Analyst: A discount would lift product sales and, on this evidence, lift returns with them. We would be buying the chart.")

    pdf.h1("29A. Worked example — one order, end to end")
    pdf.body(
        "The following walk-through uses the rules, not a promise that these exact identifiers exist. "
        "It is here so a reviewer can teach the model to someone who will not read Section 14."
    )
    pdf.h2("Commercial facts")
    pdf.bullet("Customer C00042, region West, acquisition channel Paid Search, signup 2024-03-02, loyalty None.")
    pdf.bullet("Order O50110 on 2024-11-03, channel Email (note: converting channel is not the acquisition channel).")
    pdf.bullet("Line 1: wool coat, list 220, discount 0, quantity 1, line revenue 220, line cost 78.")
    pdf.bullet("Line 2: leather sneaker, list 140, discount 10 percent, unit price 126, quantity 1, line revenue 126, line cost 44.")
    pdf.bullet("Subtotal 346, which is above 75, so shipping is 0. Tax is 7 percent of 346 = 24.22. Order total 370.22.")
    pdf.bullet("Status delivered. Payment captured on Visa for 370.22.")
    pdf.h2("What counts")
    pdf.body(
        "Revenue includes 370.22. Product sales include 346 and exclude shipping and tax; both statements are true and they are not the same metric. "
        "Contribution before returns is 346 minus 122 = 224. If the coat is later refunded for the size reason, refunded cash increases by 220, and contribution after refunds on that line falls by 220, not by the order total. "
        "Tax is not refunded in this simplified case; the status page must say the estimated refund is merchandise only, which is why FR-04's confirm screen has that sentence. "
        "The customer's cohort month is November 2024 if this is their first non-cancelled order, even though they signed up in March. Signup month is a different question and is labelled as such."
    )
    pdf.h2("What must not happen")
    pdf.bullet("The session that converted may show session_revenue of 190. That number is not added to 370.22.")
    pdf.bullet("If the order had been cancelled, none of the 370.22 would be revenue, and there would be no return path.")
    pdf.bullet("A pending inspection of the coat is a liability of 220, not refunded cash, until status is refunded and a provider reference exists.")
    pdf.body(
        "An interviewer who changes one fact — discount, cancellation, pending status, guest session — should hear the analyst recompute without opening a slide. That is the standard this example is for."
    )

    pdf.h1("29B. Jira backlog slice (first two sprints)")
    pdf.body(
        "The slice below is a planning proposal, not a velocity claim. Points are omitted on purpose. "
        "Order inside a sprint is top to bottom. Anything not listed remains in the backlog and is not silently started."
    )
    pdf.table(
        ["Sprint", "Key", "Story", "Dependency"],
        [
            ["1", "US-17", "Lineage: SQL in Git for every visual", "Repository"],
            ["1", "US-13", "Executive revenue, orders, AOV", "Load + mart_revenue"],
            ["1", "US-08", "Daily funnel by device and channel", "sessions.csv"],
            ["1", "US-14", "Contribution after refunds", "returns joined to lines"],
            ["2", "US-01", "Start a return from a delivered order", "Policy sign-off"],
            ["2", "US-02", "Explain ineligible lines", "US-01"],
            ["2", "US-03", "Status words match the email", "State machine"],
            ["2", "US-05", "Refund cap and provider reference", "Payment dependency"],
            ["2", "US-06", "Declined returns excluded from cash", "US-05"],
        ],
        [18, 22, 88, 58],
    )
    pdf.h2("Sprint review script")
    pdf.body(
        "The review shows three things and then stops. First, revenue from the mart beside a SQL client showing the same figure. "
        "Second, the funnel with mobile and desktop separated, and one sentence on where it breaks. "
        "Third, if sprint 2 has started, one return walked from Requested to Refunded with the amount cap demonstrated by typing a number that is too high. "
        "New ideas raised in the review are written as Decisions or parked. They are not designed in the meeting."
    )

    pdf.h1("29C. Wireframe annotation checklist")
    pdf.body(
        "Each frame exported to the repository carries these annotations in the margin, or the frame is not ready. "
        "The checklist is how design review stays about behaviour."
    )
    checks = [
        "Frame name matches a state in Section 17, including empty and error frames.",
        "Primary action is named and is the only filled button.",
        "Every status uses the controlled label, spelled as in Appendix D.",
        "Ineligibility is text, not only a disabled colour.",
        "Refund estimate states merchandise-only treatment of tax.",
        "Identifier is presented as copyable after submit.",
        "Agent search empty state does not suggest other customers.",
        "Finance amount field notes the maximum equal to the eligible net.",
        "Mobile width is shown for the customer frames. The queue may be desktop-only and is labelled as such.",
        "No loyalty enrolment, no recommendation rail, no chat overlay on the status page.",
    ]
    for i, c in enumerate(checks, 1):
        pdf.bullet(f"WF-{i:02d}. {c}")
    pdf.ln(2)
    pdf.body(
        "A design review that discusses typeface before WF-01 through WF-10 pass is postponed. "
        "Brand expression is welcome after the state machine is visible."
    )

    pdf.h1("29D. Operating policy the product encodes")
    pdf.body(
        "Policy is easy to leave in a slide and then contradict in the interface. The following is the policy this baseline encodes. "
        "Changing it is a sponsor decision, because it changes eligibility, cost, and the words on the status page."
    )
    pdf.table(
        ["Policy", "Parameter", "Where it is enforced"],
        [
            ["Return window", "30 days from delivery", "FR-01, FR-02, rule R5"],
            ["Final sale", "Not eligible; reason shown", "US-02"],
            ["Label funding", "Prepaid except low-value change-of-mind", "FR-04"],
            ["Refund ceiling", "Net merchandise of returned units", "FR-09, UAT-06"],
            ["Inspection", "Required before cash moves", "US-04, US-05"],
            ["Customer language", "Five labels, no synonyms", "FR-06, NFR-11"],
            ["Target cycle", "Median 5 days, hypothesis", "Section 2, not a system promise of 5"],
            ["Basket memory", "14 days, signed-in", "US-09"],
        ],
        [40, 70, 76],
    )
    pdf.body(
        "The five-day cycle target is deliberately not implemented as a promise on the status page. "
        "The page states the current state and the timestamp. Quoting a target the operation does not yet hit would recreate the AS-IS failure, in which agents promise dates they do not control."
    )

    pdf.h1("30. Document approval")
    pdf.body(
        "By approving this baseline the sponsor confirms scope, the metric catalogue, and the rule that reconciliation outranks presentation. "
        "Approval is not approval of the synthetic figures as a real trading result. Those figures demonstrate the machinery."
    )
    pdf.table(
        ["Role", "Name", "Decision", "Date"],
        [
            ["Sponsor (CCO)", "", "Approve / reject", ""],
            ["Finance controller", "", "KPI catalogue", ""],
            ["Head of customer operations", "", "TO-BE process", ""],
            ["Product owner", "", "Backlog matches RTM", ""],
            ["Analytics lead", "", "Mart contract", ""],
            ["Business analyst", "Portfolio author", "Issued 1.0", "27 Oct 2026"],
        ],
        [52, 40, 52, 42],
    )
    pdf.ln(2)
    pdf.h2("30.1 Statement of integrity")
    pdf.body(
        "I confirm that the datasets issued with document SF-BA-2026-001 were generated for this case, that customer identities are fictitious, "
        "that commercial targets are hypotheses, and that metric definitions in Section 14 govern any chart produced from the pack. "
        "Where the extract cannot support a real-world nuance (delivery timestamp, media cost, jurisdiction tax), the limitation is written down rather than smoothed over."
    )
    pdf.body(
        "End of baseline. Companion files: customers.csv, products.csv, orders.csv, order_items.csv, payments.csv, returns.csv, reviews.csv, sessions.csv, schema.sql."
    )

    out = ROOT / "ShopFlow_Commerce_BA_Dossier.pdf"
    pdf.output(str(out))
    print(f"pages={pdf.page_no()} path={out}")
    print(f"gmv={gmv:.2f} orders={n_orders} aov={aov:.2f} cart={cart_rate:.3f} purch={purch_rate:.3f} returns={len(returns)} refunds={ret_amt:.2f}")


if __name__ == "__main__":
    main()
