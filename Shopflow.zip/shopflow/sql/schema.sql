-- ShopFlow Commerce — PostgreSQL contract (portfolio, synthetic data)
-- Load CSVs after creating tables. Reconciliation queries are at the bottom.
-- Revenue definition: order_total where order_status <> 'cancelled'.

BEGIN;

CREATE TABLE customers (
    customer_id          text PRIMARY KEY,
    first_name           text NOT NULL,
    last_name            text NOT NULL,
    email                text NOT NULL,
    region               text NOT NULL,
    state                text NOT NULL,
    acquisition_channel  text NOT NULL,
    signup_date          date NOT NULL,
    loyalty_tier         text NOT NULL,
    marketing_opt_in     text NOT NULL
);

CREATE TABLE products (
    product_id    text PRIMARY KEY,
    product_name  text NOT NULL,
    brand         text NOT NULL,
    category      text NOT NULL,
    subcategory   text NOT NULL,
    unit_cost     numeric(12,2) NOT NULL,
    list_price    numeric(12,2) NOT NULL,
    active_flag   text NOT NULL
);

CREATE TABLE orders (
    order_id         text PRIMARY KEY,
    customer_id      text NOT NULL REFERENCES customers(customer_id),
    order_datetime   timestamp NOT NULL,
    order_status     text NOT NULL,
    channel          text NOT NULL,
    region           text NOT NULL,
    subtotal         numeric(12,2) NOT NULL,
    shipping_amount  numeric(12,2) NOT NULL,
    tax_amount       numeric(12,2) NOT NULL,
    order_total      numeric(12,2) NOT NULL,
    promo_code       text
);

CREATE TABLE order_items (
    order_id      text NOT NULL REFERENCES orders(order_id),
    line_no       integer NOT NULL,
    product_id    text NOT NULL REFERENCES products(product_id),
    quantity      integer NOT NULL CHECK (quantity > 0),
    unit_price    numeric(12,2) NOT NULL,
    discount_rate numeric(6,4) NOT NULL,
    line_revenue  numeric(12,2) NOT NULL,
    line_cost     numeric(12,2) NOT NULL,
    PRIMARY KEY (order_id, line_no)
);

CREATE TABLE payments (
    payment_id      text PRIMARY KEY,
    order_id        text NOT NULL REFERENCES orders(order_id),
    payment_method  text NOT NULL,
    payment_status  text NOT NULL,
    amount          numeric(12,2) NOT NULL,
    paid_at         timestamp NOT NULL
);

CREATE TABLE returns (
    return_id       text PRIMARY KEY,
    order_id        text NOT NULL REFERENCES orders(order_id),
    product_id      text NOT NULL REFERENCES products(product_id),
    customer_id     text NOT NULL REFERENCES customers(customer_id),
    return_reason   text NOT NULL,
    quantity        integer NOT NULL CHECK (quantity > 0),
    requested_date  date NOT NULL,
    refunded_date   date,
    refund_amount   numeric(12,2) NOT NULL CHECK (refund_amount >= 0),
    status          text NOT NULL
);

CREATE TABLE reviews (
    review_id    text PRIMARY KEY,
    order_id     text NOT NULL REFERENCES orders(order_id),
    customer_id  text NOT NULL REFERENCES customers(customer_id),
    product_id   text NOT NULL REFERENCES products(product_id),
    rating       integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_date  date NOT NULL
);

CREATE TABLE sessions (
    session_id        text PRIMARY KEY,
    session_date      date NOT NULL,
    customer_id       text,
    device            text NOT NULL,
    channel           text NOT NULL,
    pages_viewed      integer NOT NULL,
    added_to_cart     integer NOT NULL,
    reached_checkout  integer NOT NULL,
    purchased         integer NOT NULL,
    session_revenue   numeric(12,2) NOT NULL
);

CREATE INDEX orders_customer_idx ON orders (customer_id);
CREATE INDEX orders_dt_idx ON orders (order_datetime);
CREATE INDEX items_product_idx ON order_items (product_id);
CREATE INDEX returns_order_idx ON returns (order_id);
CREATE INDEX sessions_date_idx ON sessions (session_date);

-- Official revenue. Do not add session_revenue to this figure.
CREATE VIEW mart_revenue AS
SELECT
    SUM(order_total) AS revenue,
    COUNT(*)         AS orders,
    SUM(order_total) / NULLIF(COUNT(*), 0) AS aov
FROM orders
WHERE order_status <> 'cancelled';

-- Refunded cash excludes pending inspection.
CREATE VIEW mart_refunded_cash AS
SELECT COALESCE(SUM(refund_amount), 0) AS refunded_cash
FROM returns
WHERE status = 'refunded';

-- Funnel counts. Guests (null customer_id) stay in.
CREATE VIEW mart_funnel AS
SELECT
    COUNT(*) AS sessions,
    COUNT(*) FILTER (WHERE added_to_cart > 0) AS sessions_with_add,
    COUNT(*) FILTER (WHERE reached_checkout = 1) AS sessions_checkout,
    COUNT(*) FILTER (WHERE purchased = 1) AS sessions_purchased
FROM sessions;

COMMIT;

-- After \copy, reconcile:
-- SELECT * FROM mart_revenue;
-- SELECT * FROM mart_refunded_cash;
-- SELECT * FROM mart_funnel;
-- SELECT o.order_id
-- FROM orders o
-- JOIN (SELECT order_id, SUM(line_revenue) AS s FROM order_items GROUP BY 1) l USING (order_id)
-- WHERE ABS(o.subtotal - l.s) > 0.02;
